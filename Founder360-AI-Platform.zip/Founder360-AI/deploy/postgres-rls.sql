-- Run AFTER schema initialization, as the migration role.
-- Replace founder360_app with an existing restricted application role.
-- Never run production requests as a superuser, a table owner or a BYPASSRLS role.
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['startups','assignments','assessments','answers','evidence','ratings','sources','tasks','comments','report_versions','review_events','audit_logs','provider_calls'] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY',t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY',t);
    EXECUTE format('DROP POLICY IF EXISTS founder360_tenant ON %I',t);
    EXECUTE format('CREATE POLICY founder360_tenant ON %I USING (org_id = current_setting(''app.org_id'', true)) WITH CHECK (org_id = current_setting(''app.org_id'', true))',t);
  END LOOP;
END $$;
-- GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO founder360_app;
-- ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT,INSERT,UPDATE,DELETE ON TABLES TO founder360_app;
-- Auth, invitations and encrypted job metadata are intentionally service-scoped.
-- End-user ownership/assignment still must be checked in the API, in addition to RLS.
