"""Same-origin server. Build frontend first. No API calls on startup."""
import os,sys,argparse
from pathlib import Path
root=Path(__file__).resolve().parents[1]
os.chdir(root);sys.path.insert(0,str(root))
try:
    from dotenv import load_dotenv
    load_dotenv(root/'.env.local');load_dotenv(root/'.env')
except ImportError:pass
from backend.app.api import create_app
import uvicorn
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--port',type=int,default=int(os.getenv('PORT','8000')))
    parser.add_argument('--host',default=os.getenv('HOST','0.0.0.0'))
    parser.add_argument('--strictPort',action='store_true')
    args=parser.parse_args()
    port=args.port
    print(f'Founder360 AI: http://localhost:{port}',flush=True)
    uvicorn.run(create_app(),host=args.host,port=port,access_log=False)
