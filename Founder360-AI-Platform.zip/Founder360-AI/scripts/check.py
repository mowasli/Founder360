"""Run synthetic tests without inheriting production database/provider settings."""
import os,sys,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
env=dict(os.environ)
env.update({'DATABASE_URL':'','APP_ENV':'development','AI_PROVIDER':'offline','DATA_ENCRYPTION_KEY':''})
for key in ('OPENAI_API_KEY','ANTHROPIC_API_KEY'):env.pop(key,None)
for path in ('backend/tests','specification/06_tests'):
 result=subprocess.run([sys.executable,'-m','unittest','discover','-s',path,'-v'],cwd=root,env=env)
 if result.returncode:raise SystemExit(result.returncode)
print('All synthetic application and original reference-engine tests passed.')
