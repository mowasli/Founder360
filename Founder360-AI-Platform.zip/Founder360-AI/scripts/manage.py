"""Management commands: bootstrap admin, synthetic demo, backup and restore verification."""
import os,sys,json,argparse,getpass,sqlite3,shutil,time
from pathlib import Path
root=Path(__file__).resolve().parents[1];os.chdir(root);sys.path.insert(0,str(root))
try:
 from dotenv import load_dotenv
 load_dotenv(root/'.env.local');load_dotenv(root/'.env')
except ImportError:pass
from backend.app.storage import Store,create_user,uid,now,digest
from backend.app.fixtures import synthetic_snapshot
from backend.app.reports import build_report
from backend.app.catalog import VERSION

def main():
 parser=argparse.ArgumentParser()
 sub=parser.add_subparsers(dest='command',required=True)
 admin=sub.add_parser('create-admin');admin.add_argument('--email',required=True);admin.add_argument('--name',default='Program manager')
 sub.add_parser('demo')
 sub.add_parser('cleanup-trials')
 backup=sub.add_parser('backup');backup.add_argument('destination')
 verify=sub.add_parser('verify-backup');verify.add_argument('directory')
 args=parser.parse_args();store=Store()
 if args.command=='create-admin':
  password=getpass.getpass('New administrator password (12+ chars): ')
  u=create_user(store,args.email,password,args.name,role='admin')
  print('Administrator created:',args.email,'Organization:',u['org_id'])
 elif args.command=='demo':
  if store.production:raise SystemExit('Synthetic seeding is disabled in production')
  password=os.getenv('F360_DEMO_PASSWORD') or getpass.getpass('Choose password for synthetic demo accounts (12+ chars): ')
  emails=['manager@demo.invalid','mentor@demo.invalid','marketplace@demo.invalid','services@demo.invalid','saas@demo.invalid']
  if any(store.one('SELECT id FROM users WHERE email_hash=?',(digest(e),)) for e in emails):raise SystemExit('Demo accounts already exist; no duplicate data was added')
  manager=create_user(store,emails[0],password,'مدير برنامج اصطناعي',role='admin')
  mentor=create_user(store,emails[1],password,'مرشد اصطناعي',manager['org_id'],'mentor')
  for i,kind in enumerate(('marketplace','services','saas')):
   user=create_user(store,emails[i+2],password,'مؤسس اصطناعي '+kind,manager['org_id'])
   snap=synthetic_snapshot(kind,'idea' if kind=='services' else 'early_revenue' if kind=='saas' else 'mvp')
   sid=uid();aid=uid();snap['company']['founder_name']=store.unpack(user['profile'])['name']
   report=build_report(snap)
   with store.connect(manager['org_id']) as c:
    c.execute('INSERT INTO startups VALUES(?,?,?,?,?,?)',(sid,manager['org_id'],user['id'],store.pack(snap['company']),1,now()))
    c.execute('INSERT INTO assignments VALUES(?,?,?)',(manager['org_id'],sid,mentor['id']))
    c.execute('INSERT INTO assessments VALUES(?,?,?,?,?,?,?,?,?,?)',(aid,manager['org_id'],sid,VERSION,'baseline',store.pack({'finance':snap['finance']}),store.pack(report),0,0,now()))
    for qid,a in snap['answers'].items():c.execute('INSERT INTO answers VALUES(?,?,?,?,?)',(manager['org_id'],aid,qid,store.pack(a),now()))
    for tasks in report['action_plan'].values():
     for t in tasks:c.execute('INSERT INTO tasks VALUES(?,?,?,?,?)',(aid+'-'+t['id'],manager['org_id'],aid,store.pack(t),'planned'))
  print('Synthetic accounts created. No real founder data or real market findings:')
  for email in emails:print(email)
  print('Use the password you selected. No production credentials were created.')
 elif args.command=='cleanup-trials':
  users=store.all('SELECT id,org_id,profile FROM users')
  removed=0
  for u in users:
   p=store.unpack(u['profile'])
   if not p.get('synthetic_trial') or p.get('trial_expires_at',0)>time.time():continue
   org=u['org_id']
   rows=store.all('SELECT e.blob_name FROM evidence e JOIN assessments a ON a.id=e.assessment_id JOIN startups s ON s.id=a.startup_id WHERE s.owner_id=? AND e.org_id=?',(u['id'],org),org)
   with store.connect(org) as c:
    c.execute('DELETE FROM startups WHERE owner_id=? AND org_id=?',(u['id'],org))
    c.execute('DELETE FROM users WHERE id=? AND org_id=?',(u['id'],org))
    c.execute('DELETE FROM organizations WHERE id=?',(org,))
   for r in rows:(store.blobs/r['blob_name']).unlink(missing_ok=True)
   removed+=1
  print('Expired isolated synthetic trial workspaces removed:',removed)
 elif args.command=='backup':
  if store.url:raise SystemExit('For PostgreSQL use pg_dump + encrypted evidence/key backup; see deployment guide.')
  dest=Path(args.destination).resolve()
  if dest.exists():raise SystemExit('Destination must not exist')
  dest.mkdir(parents=True,mode=0o700)
  with sqlite3.connect(store.root/'founder360.sqlite3') as src,sqlite3.connect(dest/'founder360.sqlite3') as target:src.backup(target)
  if (store.root/'encryption.key').exists():shutil.copy2(store.root/'encryption.key',dest/'encryption.key')
  shutil.copytree(store.blobs,dest/'evidence');print('Backup created. Keep its encryption key separately under restricted access:',dest)
 elif args.command=='verify-backup':
  path=Path(args.directory).resolve()
  with sqlite3.connect(path/'founder360.sqlite3') as c:
   assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
   check=Store(path)
   row=c.execute('SELECT profile FROM users LIMIT 1').fetchone()
   if row:assert check.unpack(row[0])
  print('Backup database integrity and decryption verified. A live restore drill is still an operator responsibility.')
if __name__=='__main__':main()
