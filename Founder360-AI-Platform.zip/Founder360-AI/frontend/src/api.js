let csrf='';
export function setCsrf(token){csrf=token||''}
export async function api(path,options={}){
 const headers={...(options.body && !(options.body instanceof FormData)?{'Content-Type':'application/json'}:{}),'X-CSRF-Token':csrf,...options.headers};
 const response=await fetch('/api/v1'+path,{...options,headers,credentials:'same-origin',body:options.body && !(options.body instanceof FormData)?JSON.stringify(options.body):options.body});
 if(!response.ok){let error;try{error=await response.json()}catch{error={detail:'Service unavailable'}}let d=error.detail;throw new Error(Array.isArray(d)?d.map(e=>e.loc.join('.')+': '+e.msg).join(' / '):String(d||response.status));}
 return response.status===204?null:response.json();
}
export const download=(path)=>{const a=document.createElement('a');a.href='/api/v1'+path;a.rel='noopener';a.click()};
