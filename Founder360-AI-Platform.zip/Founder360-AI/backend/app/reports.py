"""Inspectable, schema-validated diagnostic. External text cannot alter scoring."""
import json, hashlib
from datetime import datetime, timezone, timedelta
from jsonschema import Draft202012Validator
from .catalog import PILLARS, QUESTION_MAP, VERSION, APP_RULES_VERSION, REPORT_SCHEMA
from .scoring import assess_criteria, aggregate
from .finance import calculate

# Original operational playbooks. These are proposed actions, not market findings.
PLAYBOOKS = {
 'problem':('سجّل آخر مواقف المشكلة وتكلفتها بدل سؤال العميل إن كان يحب الفكرة.','Record recent problem incidents and their cost instead of asking whether people like the idea.'),
 'customers':('حدّد المستخدم والمشتري والدافع وصاحب الموافقة لشريحة واحدة.','Map user, buyer, payer and approver for one narrow segment.'),
 'value':('اختبر وعد قيمة واحدًا بنتيجة يستطيع العميل ملاحظتها.','Test one value promise against an outcome the customer can observe.'),
 'product':('راقب إتمام المهمة الأساسية، وسجّل موضع التعثر دون مساعدة المستخدم.','Observe the core task and record failure points without coaching the user.'),
 'market':('ابنِ تقديرًا من عدد مشترين محليين يمكن الوصول إليهم وإنفاق موثق وسنة محددة.','Estimate from reachable local buyers and sourced annual spending in an explicit year.'),
 'competition':('قارن البدائل المحلية، بما فيها واتساب والمورد التقليدي، بروابط وملاحظات مؤرخة.','Compare local alternatives, including WhatsApp and incumbent suppliers, with dated links and observations.'),
 'business_model':('تتبّع معاملة واحدة: من يدفع، متى يصل النقد، ومن يتحمل تكلفة التسليم.','Trace one transaction: who pays, when cash arrives and who bears delivery costs.'),
 'pricing':('اطلب التزامًا مدفوعًا بالسعر المعروض، وسجّل الرفض والخصم والاسترداد.','Request a paid commitment at the offered price and log rejections, discounts and refunds.'),
 'unit_econ':('اجمع تكلفة كل معاملة بعد التوصيل والعمولات والمرتجعات، ثم احسب مساهمتها.','Collect each transaction cost after fulfillment, fees and returns, then calculate contribution.'),
 'finance':('طابق النقد المحصّل والمدفوع مع سجل شهري، ثم أدخل محركات ثلاثة سيناريوهات.','Reconcile monthly cash collected and paid, then enter explicit drivers for three scenarios.'),
 'marketing':('اختبر قناة واحدة ورسالة واحدة، وتتبّع مصدر كل محادثة شراء.','Test one channel and one message, tracking the source of every buying conversation.'),
 'sales':('تتبّع الفرصة من أول اتصال إلى تحصيل النقد وسجّل أسباب الخسارة.','Track each opportunity from first contact through cash collection and record losses.'),
 'traction':('قِس عودة المجموعة نفسها أو تكرار الشراء بدل جمع الزيارات الكلية.','Measure same-cohort return or repeat purchase rather than aggregate visits.'),
 'operations':('نفّذ الخدمة على نطاق صغير وسجّل وقت التسليم والعيوب واختناق السعة.','Deliver a small batch and record lead time, defects and the capacity bottleneck.'),
 'team':('عيّن مالكًا واضحًا للبيع والمنتج والنقد وحدد وقت كل شخص وأسلوب القرار.','Assign clear owners for sales, product and cash, with time commitments and decision rights.'),
 'technology':('اختبر استعادة نسخة احتياطية وراجع الحد الأدنى من البيانات والصلاحيات.','Test a backup restore and review minimum data collection and access privileges.'),
 'regulatory':('اعرض النشاط وتدفق المال والبيانات على مختص محلي وحدد الموافقات غير المحسومة.','Review activity, money and data flows with a qualified local specialist; list unresolved approvals.'),
 'partnerships':('حدّد تبادل قيمة قابلًا للقياس واختبره مع شريك قبل توقيع التزام حصري.','Define a measurable value exchange and pilot it with a partner before exclusivity.'),
 'investment':('اربط كل استخدام للتمويل بإثبات محدد وقارن الإيراد والمنح والتمويل المخفف للملكية.','Tie each use of funds to a proof milestone and compare revenue, grants and equity.'),
 'resilience':('ضع مؤشر إنذار وخطة بديلة لمخاطر النقد والمورد والاتصال قبل التوسع.','Set warning indicators and fallback plans for cash, supply and connectivity before expanding.')
}

def choose(locale,ar,en):return ar if locale=='ar' else en

def make_experiment(pillar,company,locale,index=0):
    model=company.get('business_type')
    if pillar['id'] in ('unit_econ','finance') and company.get('has_revenue'):
        method=choose(locale,'راجع 5 معاملات مكتملة بعينة متاحة من سجلاتك، مع كل تكاليفها المباشرة.','Review 5 completed transactions from available records with all direct costs.')
        metric=choose(locale,'مساهمة المعاملة والتحصيل في الموعد','Transaction contribution and on-time collection')
        pass_rule=choose(locale,'شرط مقترح: مساهمة إجمالية موجبة بعد جميع التكاليف المباشرة؛ راجع ملاءمته قبل الاختبار.','Provisional gate: positive total contribution after all direct costs; confirm suitability before testing.')
        fail_rule=choose(locale,'إذا كانت المساهمة صفرًا أو سالبة، أوقف التوسع وراجع السعر أو التكلفة.','If contribution is zero or negative, pause expansion and revise price or cost.')
        sample='5 completed transactions (proposed sample; not population inference)'
    elif pillar['id'] in ('unit_econ','finance'):
        method=choose(locale,'جهّز عرض تكلفة لخدمة أو وحدة واحدة، واطلب 3 عروض أو أسعار موارد متاحة ثم قارنها بسعر تجربة معلن. لا نطلب معاملات لم تحدث.','Cost one proposed delivery/unit using 3 available resource quotes and compare it with an explicit pilot price. Do not invent past transactions.')
        metric=choose(locale,'السعر المقترح ناقص التكاليف المتغيرة الموثقة بعروض سعر','Proposed pilot price minus quoted variable delivery costs')
        pass_rule=choose(locale,'مساهمة موجبة عند السعر الذي وافق عليه مشترٍ فعلي؛ يظل تقدير التكلفة افتراضًا حتى التسليم.','Positive contribution at a price an actual buyer accepts; quoted cost remains an assumption until delivery.')
        fail_rule=choose(locale,'التكلفة تساوي السعر أو تتجاوزه: غيّر النطاق أو السعر قبل بناء الخدمة.','If cost meets or exceeds accepted price, revise scope or price before building.')
        sample='3 resource quotes and one proposed unit; not historical unit economics'
    elif pillar['id'] in ('problem','customers'):
        method=choose(locale,'أجرِ 5 محادثات عن آخر موقف فعلي للمشكلة مع الشريحة الأولى؛ حدّد من يتخذ قرار الشراء ومن يدفع.','Run 5 recent-incident interviews with the first segment; establish who decides and pays.')
        metric=choose(locale,'مواقف حديثة متكررة مع تكلفة أو بديل فعلي وصاحب قرار محدد','Recent repeated incidents with actual cost/workaround and a named buying role')
        pass_rule=choose(locale,'حد تعلم مقترح: 3 من 5 يصفون موقفًا حديثًا ذا تكلفة أو بديل فعلي؛ لا يعتبر إثبات طلب سوقي.','Provisional learning gate: 3 of 5 describe a recent costly incident or actual workaround; not market-demand proof.')
        fail_rule=choose(locale,'لا مواقف حديثة لدى 4 من 5: راجع أولوية المشكلة أو تعريف الشريحة.','4 of 5 cannot describe a recent incident: revisit priority or segment definition.')
        sample='5 accessible target buyers; purposive, not statistically representative'
    elif pillar['id']=='market':
        method=choose(locale,'راجع قائمة مشترين محليين ضمن نطاق واضح مع مصدرين، ثم افحص قدرة الوصول والبيع في سنة واحدة.','Reconcile a bounded local buyer list against two sources, then check one-year reach and sales capacity.')
        metric=choose(locale,'عدد مشترين يمكن الوصول إليهم مع مصدر وسنة، وقدرة بيع محددة','Reachable buyers with source/year and explicit sales capacity')
        pass_rule=choose(locale,'مصدران متوافقان في تعريف المشتري والسنة، وحد بيع لا يتجاوز القدرة التشغيلية؛ لا نثبت حجم السوق من عينة صغيرة.','Two sources align on buyer definition/year; attainable sales stay within operating capacity. A small sample cannot validate market size.')
        fail_rule=choose(locale,'تعارض تعريف الشريحة أو غياب مصدر قابل للفحص: احجب TAM/SAM/SOM حتى التوضيح.','Conflicting buyer definitions or no attributable source: withhold TAM/SAM/SOM until clarified.')
        sample='Two attributable sources + bounded local contact list; no census claim'
    elif pillar['id']=='regulatory':
        method=choose(locale,'راجع وصف النشاط وتدفق المال والبيانات مع مختص محلي، واطلب قائمة موافقات ومصادر رسمية.','Review activity, money and data flows with a qualified local specialist and request official approval requirements.')
        metric=choose(locale,'قائمة عوائق وموافقات مع مصدر رسمي ومسؤول تحقق','Documented approvals/blockers with an official source and review owner')
        pass_rule=choose(locale,'توثيق المتطلبات وعدم بدء نشاط منظّم قبل الموافقات اللازمة؛ مراجعة بشرية مطلوبة.','Document applicable requirements and do not start regulated activity before required approvals; human review is essential.')
        fail_rule=choose(locale,'متطلب جوهري غير محسوم: أوقف الجزء المعني من التجربة حتى التحقق.','Unresolved material requirement: pause the relevant pilot activity pending verification.')
        sample='One qualified jurisdiction-specific review; not a legal clearance certificate'
    elif model=='marketplace':
        method=choose(locale,'نفّذ مطابقة يدوية بين 3 مشترين و3 موردين في المدينة المستهدفة وسجّل العرض والطلب والتحصيل.','Manually match 3 buyers and 3 suppliers in the target city; log supply, demand and collection.')
        metric=choose(locale,'مطابقات مدفوعة مكتملة ومساهمة كل مطابقة','Completed paid matches and contribution per match')
        pass_rule=choose(locale,'حد مقترح: إتمام مطابقتين مدفوعتين بهامش موجب ضمن وعد التسليم المتفق عليه.','Provisional gate: two paid matches at positive contribution within the agreed delivery promise.')
        fail_rule=choose(locale,'رفض الطرفين أو مساهمة غير موجبة: راجع الشريحة أو تدفق المعاملة.','Two-sided refusal or nonpositive contribution: revise segment or transaction flow.')
        sample='3 buyers + 3 suppliers; purposive pilot, not market validation'
    elif model=='saas':
        method=choose(locale,'راقب 5 مستخدمين من الشريحة المستهدفة أثناء إنجاز المهمة الأساسية دون مساعدة.','Observe 5 target users performing the core task without help.')
        metric=choose(locale,'إتمام المهمة دون مساعدة وسبب التعثر','Unassisted task completion and failure cause')
        pass_rule=choose(locale,'حد تعلم مقترح: إتمام 4 من 5 للمهمة دون مساعدة؛ لا يدل وحده على ملاءمة السوق.','Provisional learning gate: 4 of 5 complete the task unassisted; this alone is not product-market fit.')
        fail_rule=choose(locale,'إتمام 2 أو أقل: أصلح أكبر عائق وأعد الاختبار؛ 3 نتيجة غير حاسمة.','2 or fewer complete: fix the main blocker and retest; 3 is inconclusive.')
        sample='5 target users; convenience-sample bias must be recorded'
    else:
        method=choose(locale,'تحدث مع 5 مشترين محتملين عن آخر موقف حقيقي، ثم اعرض تجربة صغيرة بسعر واضح.','Interview 5 potential buyers about a recent incident, then offer a small trial at an explicit price.')
        metric=choose(locale,'مواقف موثقة والتزام شراء حقيقي','Documented incidents and actual buying commitment')
        pass_rule=choose(locale,'حد مقترح: 3 مواقف حديثة والتزام مدفوع واحد يمكن تسليمه بالموارد المتاحة.','Provisional gate: 3 recent incidents and one paid commitment deliverable with available resources.')
        fail_rule=choose(locale,'لا مواقف حديثة أو لا التزام بعد عرض واضح: راجع أولوية المشكلة والشريحة.','No recent incidents or no commitment after a clear offer: revisit problem priority and segment.')
        sample='5 accessible buyers; purposive, not statistically representative'
    hypotheses={
      'problem':('المشكلة أولوية متكررة ذات تكلفة فعلية للشريحة الأولى.','The problem is a repeated, costly priority for the initial segment.'),
      'customers':('نستطيع الوصول إلى مشترٍ محدد يملك قرار وميزانية الشراء.','We can reach a specific buyer with decision authority and budget.'),
      'unit_econ':('سعر يقبله مشترٍ يغطي جميع التكاليف المتغيرة للوحدة.','A price accepted by a buyer exceeds every variable delivery cost.'),
      'finance':('يمكن تمويل التجربة دون إخلال بالتزامات النقد المستحقة.','The pilot can be funded while meeting cash obligations.'),
      'value':('النتيجة المعروضة تكفي لتغيير سلوك عميل من البديل الحالي.','The offered outcome is enough to change behavior from the current workaround.'),
      'product':('يمكن للمستخدم إكمال المهمة الأساسية دون مساعدة مؤسس.','Users can complete the core task without founder assistance.'),
      'market':('عدد المشترين الممكن الوصول إليهم يدعم تجربة قابلة للتنفيذ ضمن قدرة الفريق.','Reachable buyers support a feasible pilot within team capacity.'),
      'regulatory':('يمكن تنفيذ نطاق التجربة بعد استيفاء الموافقات المحلية الموثقة.','The scoped pilot can operate after documented local approvals are met.')}
    hypothesis=hypotheses.get(pillar['id'],('يمكن تسليم وعد النشاط إلى الشريحة الأولى بتكلفة وموارد مقبولة.','The venture promise can be delivered to the initial segment within cost and resource constraints.'))
    return {'id':f'exp-{pillar["id"]}','pillar_id':pillar['id'],
        'hypothesis':hypothesis[0 if locale=='ar' else 1],
        'null_alternative':choose(locale,'لا يتغير سلوك المشتري أو لا تسمح الموارد بتسليم الوعد.','Buyer behavior does not change or resources cannot deliver the promise.'),
        'method':method,'sample':sample,'metric':metric,'pass_rule':pass_rule,'fail_rule':fail_rule,'days':7 if index==0 else 14,
        'cost_estimate':{'amount':None,'currency':company.get('currency'),'basis':'unknown; owner must obtain quotes before spending','spending_cap':company.get('experiment_budget')},
        'owner':company.get('founder_name') or choose(locale,'المؤسس','Founder'),
        'recruitment':choose(locale,f'تواصل مباشر مع {company.get("first_segment") or "الشريحة الأولى"} في {company.get("city","")}.',f'Direct contact with {company.get("first_segment") or "the initial segment"} in {company.get("city","") }.'),
        'baseline':None,'threshold_basis':'proposed learning threshold; founder and mentor must approve',
        'bias':choose(locale,'عينة صغيرة متاحة؛ راقب تحيز الأصدقاء والاختيار ولا تعمم النتيجة.','Small accessible sample; record selection/friend bias and do not generalize.'),
        'decision_after_result':choose(locale,'نجاح: تجربة أوسع محدودة. فشل: تعديل الفرضية. نتيجة مختلطة: قياس إضافي.','Pass: a bounded larger test. Fail: revise hypothesis. Mixed: gather more evidence.')}

def build_report(snapshot,report_id=None):
    company=dict(snapshot['company']);locale=snapshot.get('locale','ar')
    answers=snapshot.get('answers',{});reviews=snapshot.get('reviews',{})
    cs=assess_criteria(company,answers,reviews)
    pillars,overall=aggregate(cs)
    claims=[];sources=[]
    for qid,a in answers.items():
        if a.get('status')!='answered':continue
        cid='answer-'+qid
        claims.append({'claim_id':cid,'claim':a.get('text',''),'classification':'founder_reported',
            'source_ids':['answer:'+qid]+a.get('evidence_ids',[]),'checked_at':None,
            'confidence':'low','confidence_reason':choose(locale,'تصريح مؤسس؛ إرفاق ملف لا يساوي التحقق منه.','Founder statement; attachment does not establish verification.'),
            'pillar_id':QUESTION_MAP[qid]['pillar_id']})
    for e in snapshot.get('evidence',[]):
        sources.append({'id':e['id'],'title':e['name'],'url':None,'published_at':None,'accessed_at':e.get('created_at'),
            'kind':'founder_file','sha256':e.get('sha256'),'verification_status':'unreviewed','allowed_use':'private founder evidence only'})
    ext=snapshot.get('sources',[])
    for s in ext:
        sources.append({'id':s['id'],'title':s['title'],'url':s['url'],'published_at':s.get('published_at'),
            'accessed_at':s.get('checked_at'),'geography':s.get('geography'),'sector':s.get('sector'),
            'verification_status':s.get('status','unverified'),'allowed_use':s.get('allowed_use','link_only'),
            'license_url':s.get('license_url'),'license_checked_at':s.get('license_checked_at'),
            'expires_at':s.get('expires_at'),'conflicts_with':s.get('conflicts_with',[]),'comparison_limits':s.get('limits','')})
        claims.append({'claim_id':'source-'+s['id'],'claim':s.get('claim',''),
            'classification':'verified_external' if s.get('status')=='verified' else 'hypothesis',
            'source_ids':[s['id']],'checked_at':s.get('checked_at'), 'confidence':'medium' if s.get('status')=='verified' else 'low',
            'confidence_reason':'Human source review recorded' if s.get('status')=='verified' else 'Candidate source; not independently reviewed',
            'reviewer_id':s.get('reviewer_id')})
    for p in pillars:
        pcs=[c for c in claims if c.get('pillar_id')==p['id']]
        unknown=[c for c in p['criteria'] if c['applicable'] and c['score'] is None]
        known=[c for c in p['criteria'] if c['score'] is not None]
        p['supporting_claim_ids']=[c['claim_id'] for c in pcs]
        p['reasoning']=choose(locale,
            f'{len(known)} من 5 مؤشرات لها تقييم قابل للتتبع. تصريحات المؤسس ليست تحققًا مستقلًا. الأوزان: {p["base_weight_pct"]}%.',
            f'{len(known)} of 5 criteria have attributable ratings. Founder statements are not independent verification. Weight: {p["base_weight_pct"]}%.')
        p['strengths']=[choose(locale,'معلومة محددة صرّح بها المؤسس: ','Specific founder-reported information: ')+c['claim'][:220] for c in pcs[:2]]
        p['gaps']=[c['name_ar'] if locale=='ar' else c['indicator'] for c in unknown]
        target=(unknown or p['criteria'])[0]
        second=(unknown or p['criteria'])[min(1,len(unknown or p['criteria'])-1)]
        p['recommendations']=[PLAYBOOKS[p['id']][0 if locale=='ar' else 1],
             choose(locale,f'وثّق «{target["name_ar"]}» لسوق {company.get("city","")} بفترة وعينة ومصدر.',f'Document {target["indicator"]} for {company.get("city","")} with period, sample and source.'),
             choose(locale,f'اختبر «{second["name_ar"]}» قبل زيادة الإنفاق، وحدد النتيجة التي ستغيّر قرارك.',f'Test {second["indicator"]} before more spending and define the outcome that changes your decision.')]
        p['recommendation_details']=[{'action':action,'reason':choose(locale,'فجوة الدليل أو ضعف التحقق في المؤشرات المعروضة.','Missing or weakly verified evidence in the listed criteria.'),
             'claim_ids':p['supporting_claim_ids'],'criterion_ids':[target['id'],second['id']],
             'owner':company.get('founder_name') or 'Founder','cost':{'amount':None,'currency':company.get('currency'),'basis':'quote required'},
             'resources':{'available_founder_hours_week':company.get('hours_per_week')},'due_days':7 if i==0 else 30} for i,action in enumerate(p['recommendations'])]
        p['counter_evidence']=[r['reason'] for c,r in reviews.items() if c.startswith(p['id'].upper()+'_') and r.get('score')==0]
        p['follow_up_question_ids']=[q for q,a in answers.items() if QUESTION_MAP[q]['pillar_id']==p['id'] and a.get('status')=='unknown']
        p['priority']='high' if p['score'] is None or p['score']<2 else 'medium'
        p['confidence']='medium' if any(c['reviewed'] for c in p['criteria']) else 'low'
        p['status']='unknown' if p['score'] is None else 'founder_reported' if not any(c['reviewed'] for c in p['criteria']) else 'reviewed'
    ranked=sorted(pillars,key=lambda p:(p['score'] is not None,p['score'] if p['score'] is not None else -1,-p['weight']))
    experiments=[make_experiment(p,company,locale,i) for i,p in enumerate(ranked[:3])]
    assumptions=[{'claim':e['hypothesis'],'impact':'high','uncertainty':'high','test':e['id'],
                  'classification':'hypothesis','ranking_basis':'missing/weak score, applicable pillar weight; no success probability'} for e in experiments]
    action_plan={}
    for days in (7,30,60,90):
        actions=[]
        for i,e in enumerate(experiments):
            actions.append({'id':f'd{days}-{e["pillar_id"]}','title':
                e['method'] if days==7 else choose(locale,
                    {30:'نفّذ الاختبار وراجع قرار الاستمرار أو التعديل',60:'أعد الاختبار بمجموعة أخرى وقارن السلوك والهامش',90:'حدّث التشخيص وأغلق الفجوات بالدليل قبل التوسع'}[days],
                    {30:'Run the test and review proceed/revise decision',60:'Repeat with another cohort and compare behavior and margin',90:'Repeat the diagnostic and close evidence gaps before expansion'}[days]),
                'owner':e['owner'],'experiment_id':e['id'],'days':days,
                'due_date':(datetime.now(timezone.utc)+timedelta(days=days)).date().isoformat(),
                'cost':e['cost_estimate'],'resources':choose(locale,'وقت المؤسس، سجل معاملات أو مقابلات، ومراجعة مرشد','Founder time, transaction/interview log and mentor review'),
                'metric':e['metric'],'pass_rule':e['pass_rule'],'fail_rule':e['fail_rule'],
                'dependency':[] if days==7 else [f'd{ {30:7,60:30,90:60}[days]}-{e["pillar_id"]}'],
                'status':'planned','linked_claim_ids':ranked[i]['supporting_claim_ids']})
        action_plan['days_'+str(days)]=actions
    financials=calculate(snapshot.get('finance',{}),company.get('business_type'))
    recorded_revenue=snapshot.get('finance',{}).get('metrics',{}).get('revenue',{}).get('value')
    if not company.get('has_revenue') and recorded_revenue is not None and float(recorded_revenue)>0:
        financials['warnings'].append({'code':'PROFILE_REVENUE_CONFLICT','message':'Intake says no revenue, but financial inputs contain positive revenue. Review the intake and revenue definition; nothing was overwritten.'})
    for name,m in financials['metrics'].items():
        if m.get('value') is not None:
            claims.append({'claim_id':'calc-'+name,'claim':f'{name}: {m["value"]} ({m.get("currency") or m.get("unit")})',
                'classification':m['classification'],'source_ids':['financial:'+k for k in m['input_refs']],
                'checked_at':snapshot.get('created_at'),'formula':m['formula'],'confidence':'low' if m['classification']=='estimated' else 'medium'})
    overall['readiness_label']=choose(locale,'لا توجد أدلة كافية للتقييم العام','Insufficient evidence for an overall rating') if overall['overall_score'] is None else choose(locale,'درجة جاهزية الأدلة والتنفيذ','Evidence and execution readiness')
    overall['verified_criterion_coverage_pct']=round(100*sum(c['reviewed'] and c['score'] is not None for c in cs)/100,1)
    overall['methodology_version']=VERSION;overall['rules_version']=APP_RULES_VERSION
    overall['coverage_definition']='Weighted coverage of scorable pillars; independently reviewed criterion coverage is shown separately.'
    company['answers']=answers
    def answer_text(qid):
        a=answers.get(qid,{})
        return {'value':a.get('text') if a.get('status')=='answered' else None,'classification':'founder_reported' if a.get('status')=='answered' else 'unknown','answer_id':qid}
    company['business_model_map']={
       'customer_segments':{'value':company.get('first_segment'),'classification':'founder_reported','answer_id':'intake:first_segment'},
       'value_proposition':answer_text('VALUE_02'),'channels':answer_text('MARKETING_05'),
       'customer_relationships':answer_text('CUSTOMERS_03'),'revenue_streams':answer_text('BUSINESS_MODEL_03'),
       'key_resources':answer_text('BUSINESS_MODEL_05'),'key_activities':answer_text('OPERATIONS_01'),
       'key_partners':answer_text('PARTNERSHIPS_01'),'cost_structure':answer_text('FINANCE_03')}
    company['working_templates']={
       'customer_interview_questions':[
          choose(locale,ar,en) for ar,en in [
            ('متى واجهت المشكلة آخر مرة؟','When did this last happen?'),('ما الذي حدث خطوة بخطوة؟','What happened step by step?'),
            ('كيف عالجتها وقتها؟','How did you handle it then?'),('ما البديل الذي استخدمته ولماذا؟','Which workaround did you use and why?'),
            ('ما تكلفة الوقت أو المال الفعلية؟','What actual time or money did it cost?'),('من اتخذ قرار الشراء؟','Who made the buying decision?'),
            ('من دفع وكيف تمت الموافقة؟','Who paid and how was it approved?'),('ما الذي لم ينجح في البديل الحالي؟','What failed in the current alternative?'),
            ('ماذا سيحدث إذا لم تتغير الطريقة؟','What happens if the current approach stays?'),('ما دليل النتيجة التي تريد تحسينها؟','What record shows the outcome you need to improve?')]],
       'sales_script':choose(locale,f'نخدم {company.get("first_segment","")} في {company.get("city","")}. نريد فهم آخر موقف قبل عرض أي حل. إذا ناسبك اختبار محدود، نتفق أولًا على النطاق والسعر وقياس النتيجة.',
          f'We serve {company.get("first_segment","")} in {company.get("city","")}. Before offering a solution, we want to understand a recent incident. If a small pilot fits, agree scope, price and outcome measures first.'),
       'mvp_test':choose(locale,'حدد مهمة واحدة وراقب إنجازها دون مساعدة؛ سجل خط البداية والتعثر قبل إضافة مزايا.','Scope one task and observe unaided completion; record baseline and failures before adding features.'),
       'pricing_test':choose(locale,'اعرض نطاق خدمة واضحًا وسعرًا حقيقيًا؛ سجل قبولًا مدفوعًا أو رفضًا وسببه، دون سعر وهمي أو وعد لا تستطيع تسليمه.','Offer a clear scope at a real price; record paid acceptance or rejection and reason, without a price you cannot honor.')}
    company['evidence_inventory']=snapshot.get('evidence',[])
    company['research']=snapshot.get('research',{'status':'not_run','reason':'External research is not configured or not requested.'})
    company['diagnostic_mode']='deterministic rules; no model synthesis' if not snapshot.get('ai_review') else 'deterministic scores plus unverified model suggestions'
    if snapshot.get('ai_review'):company['ai_review']=snapshot['ai_review']
    company['input_digest']=hashlib.sha256(json.dumps(snapshot,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    company['decision']=choose(locale,'اختبر قبل الالتزام بإنفاق إضافي؛ راجع الفجوات والتعارضات مع المرشد.','Test before committing more spending; review gaps and contradictions with your mentor.')
    company['mentor_agenda']=[p['name_ar'] if locale=='ar' else p['name_en'] for p in ranked[:3]]
    competitors=[];analogues=[]
    for s in ext:
        if s.get('status')!='verified' or not s.get('company_name') or s.get('match_status')!='matched':continue
        if s.get('kind')=='analogue':
            analogues.append({'company_name':s['company_name'],'geography':s.get('geography',''),
                'model':s.get('model','unknown'),'transferable_lesson':s.get('lesson','unknown'),
                'limits_of_comparison':s.get('limits','unknown'),'source_ids':[s['id']]})
        elif s.get('kind')=='competitor':
            competitors.append({'company_name':s['company_name'],'geography':s.get('geography',''),
                'type':s.get('competitor_type','indirect'),'website':s['url'],'evidence':s['claim'],
                'verification_status':'verified','source_ids':[s['id']],'limits_of_comparison':s.get('limits','')})
    report={'report_id':report_id or company['input_digest'][:24],'generated_at':datetime.now(timezone.utc).isoformat(),
        'locale':locale,'company':company,'overall':overall,'pillars':pillars,'claims':claims,
        'competitors':competitors,'analogue_business_models':analogues,'assumptions':assumptions,
        'experiments':experiments,'action_plan':action_plan,'financials':financials,'sources':sources,
        'limitations':[
            choose(locale,'درجات المنهجية أولية وغير معايرة بنتائج الشركات؛ ليست احتمالية نجاح.','Prototype rubric not calibrated against company outcomes; not a probability of success.'),
            choose(locale,'الأدلة الناقصة تبقى مجهولة؛ إرفاق مستند لا يعني التحقق منه.','Missing evidence remains unknown; an uploaded document is not automatically verified.'),
            choose(locale,'الميزانيات المجهولة تتطلب عرض سعر؛ حدود نجاح التجارب مقترحات للتعلم وليست إثباتًا لملاءمة السوق.','Unknown budgets require quotes; proposed experiment thresholds support learning, not product-market-fit certification.'),
            choose(locale,'لم أتحقق من منافس أو نظير مناسب ما لم يظهر مع مصدر راجعه شخص مخول.','No suitable competitor/analogue is verified unless listed with a human-reviewed source.'),
            choose(locale,'غياب نتائج الويب لا يثبت غياب منافسين؛ راجع البدائل التقليدية وواتساب والسوق غير الرسمي.','No web results does not mean no competition; check incumbent, WhatsApp and informal substitutes.'),
            choose(locale,'الامتثال التنظيمي يحتاج مختصًا محليًا؛ لا توجد شهادة امتثال هنا.','Regulatory clearance requires qualified local review; this is not compliance certification.')
        ]}
    Draft202012Validator(REPORT_SCHEMA).validate(report)
    return report
