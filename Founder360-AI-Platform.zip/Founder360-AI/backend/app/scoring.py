"""Single deterministic score engine. Unknown is never zero."""
from math import isfinite
from .catalog import PILLARS, INDICATORS

def valid_number(x):
    return type(x) in (int, float) and isfinite(x)

def compute_pillar_score(criteria, min_coverage=.60):
    ids = [c.get('id', str(i)) for i,c in enumerate(criteria)]
    if len(set(ids)) != len(ids): raise ValueError('Duplicate criterion')
    applicable = [c for c in criteria if c.get('applicable', True)]
    for c in applicable:
        w, s = c.get('weight',1), c.get('score')
        if not valid_number(w) or w <= 0: raise ValueError('Invalid weight')
        if s is not None and (not valid_number(s) or not 0 <= s <= 4): raise ValueError('Invalid score')
    total = sum(c.get('weight',1) for c in applicable)
    known = [c for c in applicable if c.get('score') is not None]
    weight = sum(c.get('weight',1) for c in known)
    coverage = weight / total if total else 0
    return {'score':round(sum(c.get('weight',1)*c['score'] for c in known)/weight,2)
                     if weight and coverage >= min_coverage else None,
            'coverage_pct':round(coverage*100,1),
            'status': 'not_applicable' if not total else 'scored' if coverage >= min_coverage else 'insufficient_evidence'}

def compute_diagnostic(pillars, min_coverage=.60, min_pillars=10):
    ids = [p['id'] for p in pillars]
    if len(set(ids)) != len(ids): raise ValueError('Duplicate pillar')
    applicable = [p for p in pillars if p.get('applicable',True)]
    for p in applicable:
        if not valid_number(p['weight']) or p['weight'] <= 0: raise ValueError('Invalid weight')
        s = p.get('score')
        if s is not None and (not valid_number(s) or not 0 <= s <= 4): raise ValueError('Invalid score')
    total = sum(p['weight'] for p in applicable)
    known = [p for p in applicable if p.get('score') is not None]
    weight = sum(p['weight'] for p in known)
    coverage = weight / total if total else 0
    enough = coverage >= min_coverage and len(known) >= min_pillars
    return {'status':'scored' if enough else 'insufficient_evidence',
            'overall_score':round(100*sum(p['weight']*p['score']/4 for p in known)/weight,1) if enough else None,
            'evidence_coverage_pct':round(100*coverage,1), 'pillars_scored':len(known),
            'pillars_applicable':len(applicable),
            'interpretation':'Evidence and execution readiness; NOT a probability of startup success.'}

POST_LAUNCH = {'UNIT_ECON_C04','UNIT_ECON_C05','TRACTION_C02','TRACTION_C03','TRACTION_C04','TRACTION_C05'}

def assess_criteria(company, answers, reviews):
    from .catalog import QUESTION_MAP
    before_launch = company['stage'] in ('idea','discovery','prototype') and not company.get('has_users')
    result=[]
    for c in INDICATORS:
        applicable = not (before_launch and c['id'] in POST_LAUNCH)
        items = [a for qid,a in answers.items() if QUESTION_MAP.get(qid,{}).get('criterion_id')==c['id']]
        substantive = [a for a in items if a.get('status')=='answered' and a.get('text','').strip()]
        review = reviews.get(c['id'])
        score = 1 if substantive else None
        reason = 'Founder statement only; not independently verified.' if substantive else 'No attributable answer or reviewed evidence.'
        if review and review.get('score') is not None:
            score, reason = review['score'], review['reason']
        if not applicable:
            score = None
            reason = 'Measured post-launch acquisition/retention is not applicable before live users; plan a future measurement.'
        result.append({**c, 'weight':c['weight_within_pillar_pct'], 'score':score,
                       'applicable':applicable, 'reasoning':reason, 'reviewed':bool(review),
                       'review_metadata':{k:review.get(k) for k in ('reviewed_at','observed_at','reviewer_id','counter_evidence')} if review else None,
                       'source_ids':review.get('evidence_ids',[]) if review else [],
                       'answer_ids':[a.get('question_id') for a in substantive]})
    return result

def aggregate(criteria):
    pillars=[]
    for p in PILLARS:
        cs=[c for c in criteria if c['pillar_id']==p['id']]
        s=compute_pillar_score(cs)
        pillars.append({**p,**s,'weight':p['base_weight_pct'],
                        'applicable':any(c['applicable'] for c in cs),'criteria':cs})
    return pillars,compute_diagnostic(pillars)
