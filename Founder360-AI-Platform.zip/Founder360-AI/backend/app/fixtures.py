"""Explicitly synthetic fixtures. Never interpreted as market observations."""
from .catalog import read
from .models import Company
from .storage import now

def case_company(kind='marketplace',stage='mvp'):
    original=read('04_templates/SYNTHETIC_FOUNDER_CASE.json')
    base={'name':original['name'] if kind=='marketplace' else ('نواة خدمات' if kind=='services' else 'نواة SaaS')+' — حالة اصطناعية',
          'country':original['country'],'city':original['city'],'region':'Middle East',
          'sector':'commerce' if kind=='marketplace' else kind,'business_type':kind,'stage':stage,
          'currency':'YER','description':original['mission'] if kind=='marketplace' else 'منتج تجريبي اصطناعي لا يمثل شركة حقيقية',
          'first_segment':'متاجر صغيرة في المدينة — عينة اصطناعية','top_constraint':'اختبار الهامش والتحصيل والتوريد',
          'has_users':stage in ('mvp','early_revenue','growth'),'has_revenue':stage in ('early_revenue','growth') or (kind=='marketplace' and stage=='mvp'),
          'processing_consent':True,'share_program':True,'locale':'ar','hours_per_week':10}
    return Company(**base).model_dump()

def metric(value,unit='currency',source='Synthetic kit fixture; no real market data',period='2026-10'):
    return {'value':str(value) if value is not None else None,'unit':unit,'currency':'YER','period':period,'source':source,'basis':'actual'}

def synthetic_snapshot(kind='marketplace',stage='mvp'):
    company={**case_company(kind,stage),'synthetic':True,'founder_name':'مؤسس اصطناعي'}
    answers={
        'PROBLEM_01':{'question_id':'PROBLEM_01','status':'answered','text':'المتاجر تعاني من عدم انتظام التوريد — تصريح اصطناعي، ملاحظات المؤسس فقط.','evidence_ids':[],'updated_at':now()},
        'TRACTION_01':{'question_id':'TRACTION_01','status':'answered','text':'لدينا 12 متجرًا جرب الخدمة؛ لم تُرفع سجلات الطلبات — بيانات اصطناعية.','evidence_ids':[],'updated_at':now()},
        'BUSINESS_MODEL_01':{'question_id':'BUSINESS_MODEL_01','status':'answered','text':'حالة سوق متعدد الأطراف عبر واتساب؛ الفرق بين GMV وصافي إيراد المنصة يحتاج مراجعة.','evidence_ids':[],'updated_at':now()}
    }
    finance={'metrics':{'units_sold':metric(30,'orders'),'revenue':metric(750000),'variable_costs':metric(660000)}} if stage not in ('idea','discovery','prototype') else {}
    return {'company':company,'answers':answers,'reviews':{},'evidence':[],'sources':[],'finance':finance,'locale':'ar','created_at':now()}
