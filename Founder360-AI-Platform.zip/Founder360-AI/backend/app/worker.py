"""Durable, leased analysis jobs. Reports never overwrite newer founder inputs."""
import time
from .storage import now,uid
from .reports import build_report
from .providers import research,ai_review

def set_stage(store,job,stage):
    store.run('UPDATE jobs SET stage=?,lease_until=?,updated_at=? WHERE id=? AND org_id=?',
              (stage,time.time()+600,now(),job['id'],job['org_id']),job['org_id'])

def run_one(store):
    # A single worker per application instance; leases support recovery after a crash.
    with store.connect() as c:
        suffix=' FOR UPDATE SKIP LOCKED' if store.url else ''
        row=c.execute("SELECT * FROM jobs WHERE (status='queued' OR (status='running' AND lease_until<?)) AND attempts<3 ORDER BY created_at LIMIT 1"+suffix,(time.time(),)).fetchone()
        if not row:return False
        job=dict(row)
        c.execute('UPDATE jobs SET status=?,stage=?,attempts=attempts+1,lease_until=?,updated_at=? WHERE id=?',('running','validating',time.time()+600,now(),job['id']))
    org=job['org_id'];jid=job['id'];aid=job['assessment_id']
    try:
        payload=store.unpack(job['payload']);snapshot=payload['snapshot'];options=payload['options']
        # Never repeat an uncertain paid call after worker death.
        previous=store.one('SELECT id FROM provider_calls WHERE job_id=? AND org_id=?',(jid,org),org)
        if previous and job['attempts']>0:raise RuntimeError('EXTERNAL_REPLAY_REQUIRES_REVIEW')
        if options.get('research'):
            set_stage(store,job,'researching')
            snapshot['research']=research(store,org,jid,snapshot['company'])
            new_sources=snapshot['research'].get('sources',[])
            snapshot['sources']+=new_sources
        else:snapshot['research']={'status':'not_run','reason':'External research not requested; sources remain human supplied and reviewed.'}
        if options.get('ai'):
            set_stage(store,job,'reviewing')
            snapshot['ai_review']=ai_review(store,org,jid,snapshot)
        set_stage(store,job,'calculating')
        report=build_report(snapshot,jid)
        set_stage(store,job,'assembling_report')
        with store.connect(org) as c:
            current=c.execute('SELECT revision FROM assessments WHERE id=? AND org_id=?',(aid,org)).fetchone()
            if not current:
                return True
            if current['revision']!=job['input_revision']:
                c.execute('UPDATE jobs SET status=?,stage=?,updated_at=? WHERE id=? AND org_id=?',('superseded','inputs_changed',now(),jid,org))
                return True
            for s in snapshot.get('research',{}).get('sources',[]):
                c.execute('INSERT INTO sources VALUES(?,?,?,?) ON CONFLICT(id) DO NOTHING',(s['id'],org,aid,store.pack(s)))
            for actions in report['action_plan'].values():
                for action in actions:
                    tid=aid+'-'+action['id']
                    existing=c.execute('SELECT payload,status FROM tasks WHERE id=? AND org_id=?',(tid,org)).fetchone()
                    if existing:
                        old=store.unpack(existing['payload'])
                        action.update({k:old[k] for k in ('owner','note','updated_at') if k in old})
                        action['status']=existing['status']
                    c.execute('INSERT INTO tasks VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload',
                              (tid,org,aid,store.pack(action),action['status']))
            c.execute('UPDATE assessments SET report=?,report_revision=? WHERE id=? AND org_id=?',(store.pack(report),job['input_revision'],aid,org))
            c.execute('INSERT INTO report_versions VALUES(?,?,?,?,?,?)',(jid,org,aid,job['input_revision'],store.pack(report),now()))
            c.execute('UPDATE jobs SET status=?,stage=?,lease_until=0,updated_at=? WHERE id=? AND org_id=?',('completed','completed',now(),jid,org))
        store.audit({'id':'system-worker','org_id':org},aid,'report.completed')
    except Exception as e:
        known={'EXTERNAL_REPLAY_REQUIRES_REVIEW','PROVIDER_BUDGET_EXCEEDED','PROVIDER_NOT_CONFIGURED'}
        code=str(e) if str(e) in known else 'ANALYSIS_FAILED'
        store.run('UPDATE jobs SET status=?,stage=?,error_code=?,lease_until=0,updated_at=? WHERE id=? AND org_id=?',('failed','failed',code,now(),jid,org),org)
    return True

def worker_loop(store,stop):
    while not stop.is_set():
        try:worked=run_one(store)
        except Exception:worked=False
        if not worked:stop.wait(.5)
