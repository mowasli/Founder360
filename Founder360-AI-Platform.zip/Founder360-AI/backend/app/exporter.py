"""Full HTML/PDF report. All founder and source content is escaped."""
from html import escape
import io,re
from .catalog import ROOT,QUESTION_MAP,SOURCES
from .reports import choose

def blocks(report,stale=False):
    l=report['locale'];c=report['company'];o=report['overall']
    t=lambda ar,en:choose(l,ar,en)
    out=[]
    def h(s,level=1):out.append(('h'+str(level),str(s)))
    def p(s):out.append(('p',str(s)))
    def link(title,url):out.append(('link',str(title),url))
    h('Founder360 AI')
    h(c['name'],2);p(t('تشخيص الشركة وخطة تطويرها','Startup diagnostic and venture development plan'))
    p(f"{c.get('city','')} / {c['country']} | {c['stage']} | {c['sector']} | {c.get('currency','')}")
    p(report['generated_at']);p(t('حالة اصطناعية للاختبار فقط','Synthetic test case only') if c.get('synthetic') else t('خاص بالمؤسس والمرشد المصرح له','Private to founder and authorized program reviewers'))
    if stale:p(t('هذه نسخة سابقة؛ تغيرت المدخلات بعد إعداد التقرير.','Previous version: inputs changed after this report.'))
    h(t('القرار التنفيذي','Decision brief'))
    p(c['decision']);p(o['readiness_label'])
    p(f"{t('الدرجة','Score')}: {o['overall_score'] if o['overall_score'] is not None else t('محجوبة','Withheld')} | {t('تغطية الأدلة القابلة للتقييم','Scorable evidence coverage')}: {o['evidence_coverage_pct']}% | {t('مؤشرات راجعها المرشد','Reviewed criteria')}: {o['verified_criterion_coverage_pct']}%")
    p(t('هذه ليست احتمالية نجاح الشركة. تغطية التقييم تختلف عن التحقق المستقل.','This is not a probability of success. Scorable coverage differs from independent verification.'))
    h(t('الشركة في صفحة','Company snapshot'))
    for field,ar,en in [('description','وصف النشاط','Activity'),('first_segment','الشريحة الأولى','Initial segment'),('top_constraint','القيد الأهم','Top constraint'),('customer_model','المشتري','Buying model'),('hours_per_week','الساعات المتاحة أسبوعيًا','Hours/week'),('experiment_budget','سقف ميزانية التجارب','Experiment spending cap')]:
        p(f"{t(ar,en)}: {c.get(field) if c.get(field) is not None else t('غير معروف','Unknown')}")
    h(t('خريطة نموذج العمل','Business-model map'),2)
    for key,v in c.get('business_model_map',{}).items():
        p(key.replace('_',' ')+': '+str(v.get('value') or t('غير معروف','Unknown'))+' | '+v['classification']+' | '+v['answer_id'])
    h(t('حالة البحث وحدوده','Research status and limits'))
    research=c.get('research',{});p(research.get('status','not_run'));p(research.get('reason',''))
    for q in research.get('search_log',[]):p(f"{q['scope']}: {q['query']} | {q['checked_at']}")
    for title,key in [(t('المنافسون والبدائل المتحقق منها','Verified competitors and substitutes'),'competitors'),(t('نماذج أعمال مشابهة','Comparable business models'),'analogue_business_models')]:
        h(title,2)
        if not report[key]:p(t('لم أتحقق من حالة مناسبة. غياب نتائج البحث لا يثبت غياب المنافسة.','No suitable case has been verified. No search results does not establish absence of competition.'))
        for s in report[key]:
            p(s['company_name']+' | '+s['geography']);p(s.get('evidence',s.get('model','')));p(s.get('limits_of_comparison',''))
    h(t('المراجعة التفصيلية للمحاور العشرين','20-pillar diagnostic audit'))
    for i,pillar in enumerate(report['pillars'],1):
        h(f"{i:02}. {pillar['name_ar'] if l=='ar' else pillar['name_en']}",2)
        p(f"{t('الدرجة','Score')}: {pillar['score'] if pillar['score'] is not None else t('غير معروف','Unknown')} / 4 | {t('التغطية','Coverage')}: {pillar['coverage_pct']}% | {pillar['status']}")
        p(pillar['reasoning'])
        for strength in pillar['strengths']:p(strength)
        p(t('فجوات: ','Gaps: ')+(' / '.join(pillar['gaps']) or t('راجع قوة الدليل وحداثته','Review evidence strength and freshness')))
        for rec in pillar['recommendations']:p('• '+rec)
        if pillar['counter_evidence']:p(t('دليل معارض: ','Counter-evidence: ')+'; '.join(pillar['counter_evidence']))
        for criterion in pillar['criteria']:
            score=criterion['score'] if criterion['score'] is not None else t('مجهول','Unknown')
            p(f"{criterion['id']} | {criterion['name_ar'] if l=='ar' else criterion['indicator']}: {score}")
            if not criterion['applicable']:p(criterion['reasoning'])
        p(t('مراجع الادعاءات: ','Claim references: ')+(', '.join(pillar['supporting_claim_ids']) or '—'))
    h(t('الحسابات المالية وحجم السوق','Financial calculations and market sizing'))
    p(t('كل رقم محسوب مرتبط بمدخلاته. الأرقام التي صرّح بها المؤسس لم تتحقق منها جهة مستقلة.','Each calculation is linked to inputs. Founder-reported inputs are not independently verified.'))
    for name,m in report['financials']['metrics'].items():
        h(name,3);p(str(m.get('value') if m.get('value') is not None else t('غير قابل للحساب','Not calculable'))+' '+str(m.get('currency') or m.get('unit') or ''))
        p(m.get('formula',''))
        if m.get('missing'):p(t('الناقص: ','Missing: ')+', '.join(m['missing']))
        for key,v in m.get('inputs',{}).items():p(f"{key}: {v['value']} {v.get('currency','')} / {v['unit']} / {v['period']} | {v['basis']} | {v['source']}")
        for a in m.get('assumptions',[]):p(a)
    for w in report['financials']['warnings']:p(t('تنبيه مراجعة: ','Review warning: ')+w['message'])
    h(t('سيناريوهات المحركات','Driver scenarios'),2)
    for name,s in report['financials']['scenarios'].items():
        p(name+': '+(t('يتطلب إدخال محركات صريحة','Requires explicit driver inputs') if s.get('value') is None and 'revenue' not in s else f"revenue={s.get('revenue')} | cash proxy={s.get('operating_cash_proxy')} | estimated"))
        if s.get('inputs'):p(str(s['inputs']))
    h(t('الفرضيات الحرجة وتجارب التحقق','Critical assumptions and experiments'))
    for e in report['experiments']:
        h(e['hypothesis'],2)
        for key,ar,en in [('method','الإجراء','Method'),('null_alternative','البديل النافي','Null alternative'),('sample','العينة وحدودها','Sample and limits'),('recruitment','الوصول للمشاركين','Recruitment'),('metric','المقياس','Metric'),('pass_rule','معيار النجاح المقترح','Provisional pass rule'),('fail_rule','معيار الفشل','Fail rule'),('owner','المسؤول','Owner'),('days','المدة بالأيام','Days'),('bias','التحيز','Bias'),('decision_after_result','قرار ما بعد النتيجة','Decision')]:p(t(ar,en)+': '+str(e.get(key,'')))
        p(t('تكلفة غير مقدرة بعد؛ يلزم تسعير الموارد. العملة: ','Cost not yet estimated; obtain resource quotes. Currency: ')+str(e['cost_estimate'].get('currency')))
    h(t('خطة 7 / 30 / 60 / 90 يومًا','7 / 30 / 60 / 90 day roadmap'))
    for key,actions in report['action_plan'].items():
        h(key.replace('days_',t('اليوم ','Day ')),2)
        for a in actions:
            p(a['title']);p(f"{a['owner']} | {a['due_date']} | {a['status']} | {a['experiment_id']}")
            p(a['resources']);p(a['metric']);p(a['pass_rule']);p(a['fail_rule']);p(t('الاعتماد على: ','Depends on: ')+(', '.join(a['dependency']) or t('لا يوجد','None')))
    if c.get('ai_review'):
        h(t('اقتراحات النموذج غير المتحقق منها','Unverified model suggestions'))
        for s in c['ai_review'].get('suggestions',[]):p(s['text']);p(s['next_action']);p(', '.join(s['answer_ids']))
    h(t('قوالب عمل جاهزة للتخصيص','Working templates to customize'))
    templates=c.get('working_templates',{})
    h(t('مقابلة اكتشاف عميل','Customer discovery interview'),2)
    for i,question in enumerate(templates.get('customer_interview_questions',[]),1):p(str(i)+'. '+question)
    for key in ('sales_script','mvp_test','pricing_test'):
        h(key.replace('_',' '),2);p(templates.get(key,''))
    h(t('سجل الادعاءات','Claim ledger'))
    for claim in report['claims']:
        p(f"{claim['claim_id']} | {claim['classification']} | {claim.get('confidence','unknown')}")
        p(claim['claim']);p(t('المراجع: ','References: ')+', '.join(claim['source_ids']))
    h(t('المصادر وتاريخها وحدود الترخيص','Sources, freshness and permissions'))
    if not report['sources']:p(t('لا توجد مصادر خارجية راجعها مرشد في هذا التشخيص.','No mentor-reviewed external sources in this assessment.'))
    for s in report['sources']:
        if s.get('url'):link(s['id']+' | '+s['title'],s['url'])
        else:p(s['id']+' | '+s['title'])
        p(f"Published: {s.get('published_at')} | Checked: {s.get('accessed_at')} | {s.get('geography','')} | {s.get('verification_status','')} | {s.get('allowed_use','')}")
        if s.get('conflicts_with'):p('Conflicting sources retained: '+', '.join(s['conflicts_with']))
    h(t('حدود التقرير','Report limitations'))
    for s in report['limitations']:p('• '+s)
    h(t('ملحق الإجابات الأصلية','Original answer appendix'))
    for qid,a in c.get('answers',{}).items():
        h(QUESTION_MAP[qid]['question_ar' if l=='ar' else 'question_en'],3)
        p(f"{qid} | {a['status']} | founder_reported")
        p(a.get('text') or a.get('reason') or t('لا أعرف','Unknown'))
        for m in a.get('measurements',[]):p(str(m))
    h(t('المنهجية وإصدار المدخلات','Methodology and input version'))
    p(f"Report {report['report_id']} | Rubric {o['methodology_version']} | Rules {o['rules_version']}")
    p('SHA-256: '+c['input_digest']);p(c['diagnostic_mode'])
    p(t('الروابط التالية للقراءة والمنهجية وليست دليلًا على سوق الشركة:','The following links are reading/methodology references, not evidence of this company market:'))
    for s in SOURCES[:7]:link(s['source'],s['url'])
    return out

def html_report(report,stale=False):
    l=report['locale'];body=[]
    for b in blocks(report,stale):
        if b[0]=='link':body.append(f'<p><a href="{escape(b[2],quote=True)}" rel="noreferrer">{escape(b[1])}</a><br><bdi>{escape(b[2])}</bdi></p>')
        else:body.append(f'<{b[0]}>{escape(b[1])}</{b[0]}>')
    return '<!doctype html><html lang="'+l+'" dir="'+('rtl' if l=='ar' else 'ltr')+'"><head><meta charset="utf-8"><title>Founder360 report</title><style>@font-face{font-family:Arabic;src:url(/fonts/NotoSansArabic-Regular.ttf)}body{font-family:Arabic,Arial,sans-serif;max-width:900px;margin:48px auto;color:#19382d;padding:20px;line-height:1.9}h1{margin-top:48px;color:#245b45;border-bottom:1px solid #d1dbd4}h2{margin-top:32px}h3{font-size:16px}p{white-space:pre-wrap;overflow-wrap:anywhere}a{color:#245b45}bdi{font-size:11px}@media print{body{margin:0}h1,h2,h3{break-after:avoid}a{color:inherit}}</style></head><body>'+''.join(body)+'</body></html>'

def pdf_report(report,stale=False):
    from reportlab.platypus import SimpleDocTemplate,Flowable,Spacer
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.lib.colors import HexColor
    from reportlab.lib.pagesizes import A4
    import arabic_reshaper
    from bidi.algorithm import get_display
    fonts=ROOT/'frontend/public/fonts'
    for name,file in [('Universal','DejaVuSans.ttf'),('UniversalBold','DejaVuSans-Bold.ttf'),('Latin','DejaVuSans.ttf')]:
        if name not in pdfmetrics.getRegisteredFontNames():pdfmetrics.registerFont(TTFont(name,str(fonts/file)))
    rtl=report['locale']=='ar'
    def visual(s):return get_display(arabic_reshaper.reshape(s)) if re.search('[\u0600-\u06ff]',s) else s
    class Text(Flowable):
        def __init__(self,text,size=10,bold=False,color='#243e32',url=None,lines=None):
            Flowable.__init__(self);self.text=text;self.size=size;self.font='UniversalBold' if bold else 'Universal';self.color=color;self.url=url;self.lines=lines;self.leading=size*1.9
        def wrap(self,width,height):
            if self.lines is None:
                self.lines=[]
                for para in self.text.split('\n'):
                    line=''
                    for word in para.split():
                        # Split very long IDs/URLs so they cannot overflow the page.
                        chunks=[word[i:i+55] for i in range(0,len(word),55)]
                        for chunk in chunks:
                            proposed=(line+' '+chunk).strip()
                            if line and pdfmetrics.stringWidth(visual(proposed),self.font,self.size)>width:
                                self.lines.append(line);line=chunk
                            else:line=proposed
                    self.lines.append(line)
            self.width=width;self.height=len(self.lines)*self.leading+5;return width,self.height
        def split(self,width,height):
            self.wrap(width,height);n=int((height-5)//self.leading)
            if n<=0:return []
            if n>=len(self.lines):return [self]
            return [Text('',self.size,self.font=='UniversalBold',self.color,self.url,self.lines[:n]),Text('',self.size,self.font=='UniversalBold',self.color,self.url,self.lines[n:])]
        def draw(self):
            cv=self.canv;cv.setFont(self.font,self.size);cv.setFillColor(HexColor(self.color))
            for i,line in enumerate(self.lines):
                s=visual(line);y=self.height-5-(i+1)*self.leading+self.size*.3
                if rtl:cv.drawRightString(self.width,y,s)
                else:cv.drawString(0,y,s)
                if self.url:cv.linkURL(self.url,(0,y-3,self.width,y+self.size+2),relative=1,thickness=0)
    content=[]
    for b in blocks(report,stale):
        if b[0].startswith('h'):
            level=int(b[0][1]);content.append(Spacer(1,18 if level==1 else 9))
            heading=Text(b[1],18 if level==1 else 13 if level==2 else 10.5,True);heading.keepWithNext=True;content.append(heading)
        elif b[0]=='link':content.append(Text(b[1],9,color='#245b45',url=b[2]));content.append(Text(b[2],8,color='#4b6d59',url=b[2]))
        else:content.append(Text(b[1]))
    buf=io.BytesIO()
    doc=SimpleDocTemplate(buf,pagesize=A4,rightMargin=44,leftMargin=44,topMargin=50,bottomMargin=48,
                         title='Founder360 AI - '+report['company']['name'],author='Founder360 AI',pageCompression=1)
    def footer(cv,d):
        cv.setFont('Latin',8);cv.setFillColor(HexColor('#6b7b70'));cv.drawString(44,27,'Founder360 AI | '+report['report_id'][:20]);cv.drawRightString(A4[0]-44,27,str(d.page))
    doc.build(content,onFirstPage=footer,onLaterPages=footer)
    return buf.getvalue()
