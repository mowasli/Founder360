from typing import Literal
from pydantic import BaseModel, Field, ConfigDict, field_validator
from .catalog import STAGES, QUESTION_SPEC
from .finance import dec

class Strict(BaseModel):
    model_config=ConfigDict(extra='forbid',str_strip_whitespace=True)

class Register(Strict):
    email:str=Field(min_length=3,max_length=254)
    password:str=Field(min_length=12,max_length=256)
    name:str=Field(min_length=1,max_length=100)
    processing_consent:bool
    invite_token:str=Field(default='',max_length=200)

class Login(Strict):
    email:str=Field(min_length=3,max_length=254)
    password:str=Field(max_length=256)

class Company(Strict):
    name:str=Field(min_length=2,max_length=120)
    country:str=Field(min_length=2,max_length=80)
    city:str=Field(min_length=1,max_length=100)
    region:str=Field(default='',max_length=100)
    comparison_market:str=Field(default='',max_length=100)
    sector:str=Field(min_length=2,max_length=80)
    business_type:str
    customer_model:Literal['B2B','B2C','B2G','B2B2C']='B2B'
    stage:str
    currency:str=Field(pattern=r'^[A-Z]{3}$')
    description:str=Field(default='',max_length=2000)
    first_segment:str=Field(min_length=2,max_length=500)
    top_constraint:str=Field(min_length=2,max_length=1000)
    expansion_market:str=Field(default='',max_length=100)
    website:str=Field(default='',max_length=500)
    age_months:int=Field(default=0,ge=0,le=1200)
    founder_count:int=Field(default=1,ge=1,le=100)
    hours_per_week:int=Field(default=10,ge=0,le=168)
    has_users:bool=False
    has_revenue:bool=False
    infrastructure_constrained:bool=False
    experiment_budget:str|None=None
    locale:Literal['ar','en']='ar'
    processing_consent:bool
    share_program:bool=False
    external_research_consent:bool=False
    external_ai_consent:bool=False
    @field_validator('stage')
    @classmethod
    def stage_valid(cls,v):
        if v not in STAGES:raise ValueError('Unknown stage')
        return v
    @field_validator('business_type')
    @classmethod
    def business_valid(cls,v):
        if v not in QUESTION_SPEC['business_types']:raise ValueError('Unknown business model')
        return v
    @field_validator('experiment_budget')
    @classmethod
    def budget_valid(cls,v):
        dec(v);return v

class AssessmentCreate(Strict):
    startup_id:str
    label:str=Field(default='baseline',min_length=1,max_length=60)
    copy_from:str|None=None

class Answer(Strict):
    question_id:str=Field(max_length=80)
    status:Literal['answered','unknown','not_applicable']='answered'
    text:str=Field(default='',max_length=6000)
    reason:str=Field(default='',max_length=1000)
    evidence_ids:list[str]=Field(default_factory=list,max_length=10)
    measurements:list[dict]=Field(default_factory=list,max_length=10)
    share_with_ai:bool=False
    ai_excerpt:str=Field(default='',max_length=1200)

class AnalysisOptions(Strict):
    research:bool=False
    ai:bool=False
    locale:Literal['ar','en']='ar'

class Rating(Strict):
    score:int|None=Field(default=None,ge=0,le=4)
    reason:str=Field(min_length=15,max_length=3000)
    evidence_ids:list[str]=Field(default_factory=list,max_length=20)
    observed_at:str=Field(min_length=10,max_length=40)
    counter_evidence:str=Field(default='',max_length=2000)

class Source(Strict):
    title:str=Field(min_length=2,max_length=300)
    url:str=Field(min_length=10,max_length=2000)
    claim:str=Field(min_length=5,max_length=2000)
    geography:str=Field(min_length=2,max_length=160)
    sector:str=Field(default='',max_length=80)
    scope:Literal['local','regional','comparable','global']='local'
    kind:Literal['context','competitor','analogue']='context'
    company_name:str=Field(default='',max_length=160)
    competitor_type:Literal['direct','indirect','substitute']='indirect'
    model:str=Field(default='',max_length=500)
    lesson:str=Field(default='',max_length=1000)
    limits:str=Field(default='',max_length=1200)
    published_at:str|None=None
    allowed_use:Literal['link_only','metadata_only','licensed_excerpt']='link_only'
    license_url:str=Field(default='',max_length=2000)
    license_checked_at:str|None=None
    expires_at:str|None=None
    match_status:Literal['matched','uncertain','nonmatching']='uncertain'
    conflicts_with:list[str]=Field(default_factory=list,max_length=10)

class SourceReview(Strict):
    status:Literal['verified','unverified','rejected']
    reason:str=Field(min_length=15,max_length=1500)

class Comment(Strict):
    text:str=Field(min_length=1,max_length=4000)
    claim_id:str=Field(default='',max_length=100)

class TaskUpdate(Strict):
    status:Literal['planned','in_progress','completed','blocked']
    note:str=Field(default='',max_length=1500)
    owner:str=Field(default='',max_length=120)

class Invite(Strict):
    role:Literal['founder','mentor']='founder'

class Brand(Strict):
    brand_name:str=Field(min_length=2,max_length=80)
    accent:str=Field(pattern=r'^#[0-9a-fA-F]{6}$')
    logo_url:str=Field(default='',max_length=200000)
