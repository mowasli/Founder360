"""Decimal arithmetic with input traces, metadata checks and no manufactured figures."""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import re

FIELDS = ['revenue','units_sold','unit_price','unit_variable_cost','variable_costs','fixed_costs','cash_balance',
          'cash_collected','cash_paid','acquisition_spend','new_paying_customers','paying_customers','units_per_customer',
          'gmv','monthly_churn_pct','cohort_months','cohort_size','monthly_revenue_per_customer',
          'total_buyers','reachable_buyers','annual_spend','qualified_leads','sales_conversion_pct','annual_sales_capacity',
          'subscription_mrr','starting_mrr','expansion_mrr','contraction_mrr','churned_mrr','retained_customers','starting_customers',
          'billable_hours','available_hours','bom_per_unit','warranty_per_unit','other_variable_per_unit','matched_requests','valid_requests']
MONEY = set(FIELDS)-{'units_sold','new_paying_customers','paying_customers','units_per_customer','monthly_churn_pct',
                     'cohort_months','cohort_size','total_buyers','reachable_buyers','qualified_leads','sales_conversion_pct','annual_sales_capacity',
                     'retained_customers','starting_customers','billable_hours','available_hours','matched_requests','valid_requests'}

def dec(value):
    if value is None or value=='': return None
    if isinstance(value,bool): raise ValueError('Boolean is not a financial value')
    try: n=Decimal(str(value))
    except InvalidOperation: raise ValueError('Invalid number')
    if not n.is_finite() or n<0: raise ValueError('Number must be finite and non-negative')
    return n

def fmt(n):
    return str(n.quantize(Decimal('.01'),rounding=ROUND_HALF_UP)) if n is not None else None

def validate_workbook(book):
    for key,v in book.get('metrics',{}).items():
        if key not in FIELDS: raise ValueError('Unknown financial field')
        n=dec(v.get('value'))
        if n is None: continue
        for meta in ('period','unit','source','basis'):
            if not str(v.get(meta,'')).strip(): raise ValueError(f'{key}: {meta} required')
        if v['basis'] not in ('actual','assumption'): raise ValueError('Invalid financial basis')
        if key in MONEY and not re.fullmatch(r'[A-Z]{3}',v.get('currency','')): raise ValueError('ISO currency required')
        if key in ('sales_conversion_pct','monthly_churn_pct') and n>100: raise ValueError('Percentage out of range')
    for name,scenario in book.get('scenarios',{}).items():
        if name not in ('downside','base','upside'): raise ValueError('Unknown scenario')
        for key in ('units','price','variable_cost','fixed_cost'):
            if key in scenario: dec(scenario[key])
        if any(scenario.get(k) is not None for k in ('units','price','variable_cost','fixed_cost')):
            if not all(scenario.get(k) for k in ('source','period','currency')): raise ValueError('Scenario source/period/currency required')
    return book

def calculate(book,business_type=None):
    validate_workbook(book)
    metrics=book.get('metrics',{})
    output={'metrics':{},'warnings':[],'missing':[],'scenarios':{},'inputs':metrics,
            'methodology':'Decimal arithmetic; no FX conversion, no inferred missing values.'}
    def get(key):
        v=metrics.get(key,{})
        return dec(v.get('value'))
    def add(name,keys,formula,fn,unit='currency',period_type=None,extra=None):
        vals=[get(k) for k in keys]
        if any(v is None for v in vals):
            output['metrics'][name]={'value':None,'formula':formula,'missing':[k for k,v in zip(keys,vals) if v is None]};return
        periods={metrics[k]['period'] for k in keys}
        currencies={metrics[k].get('currency') for k in keys if k in MONEY}
        if len(periods)>1 or len(currencies)>1 or (period_type=='monthly' and not all(re.fullmatch(r'\d{4}-\d{2}',p) for p in periods)):
            output['warnings'].append({'code':'METADATA_MISMATCH','metric':name,'fields':keys,'message':'Periods or currencies do not match the formula; calculation withheld.'})
            output['metrics'][name]={'value':None,'formula':formula,'missing':['matching periods/currencies']};return
        try: value=fn(*vals)
        except (ZeroDivisionError,InvalidOperation): value=None
        classification='estimated' if any(metrics[k]['basis']=='assumption' for k in keys) or extra else 'calculated'
        output['metrics'][name]={'value':fmt(value),'formula':formula,'input_refs':keys,'inputs':{k:metrics[k] for k in keys},
           'unit':unit,'currency':next(iter(currencies),None) if unit=='currency' else None,'period':next(iter(periods),None),
           'classification':classification,'input_verification':'founder_reported; not independently verified','assumptions':extra or []}
    add('revenue_per_unit',['revenue','units_sold'],'net revenue / units sold',lambda r,n:r/n if n else None)
    add('contribution_total',['revenue','variable_costs'],'net revenue - truly variable costs',lambda r,c:r-c)
    add('contribution_margin_pct',['revenue','variable_costs'],'(net revenue - variable costs) / net revenue × 100',lambda r,c:(r-c)/r*100 if r else None,'%')
    add('contribution_per_unit',['unit_price','unit_variable_cost'],'unit net price - unit variable cost',lambda r,c:r-c)
    add('break_even_units',['fixed_costs','unit_price','unit_variable_cost'],'fixed costs / (unit price - unit variable cost)',lambda f,r,c:f/(r-c) if r>c else None,'units')
    if metrics.get('new_paying_customers',{}).get('unit') not in (None,'new_paying_customers'):
        output['warnings'].append({'code':'CAC_DENOMINATOR','message':'CAC requires new paying customers, not users or total customers.'})
        output['metrics']['cac']={'value':None,'missing':['new paying customer denominator']}
    else:
        add('cac',['acquisition_spend','new_paying_customers'],'attributable acquisition spend / new paying customers',lambda s,n:s/n if n else None)
    add('net_cash_burn',['cash_paid','cash_collected'],'cash paid - cash collected (same month)',lambda p,c:p-c,period_type='monthly')
    add('runway_months',['cash_balance','cash_paid','cash_collected'],'available cash / (monthly cash paid - collected)',lambda c,p,r:c/(p-r) if p>r else None,'months',period_type='monthly')
    add('take_rate_pct',['revenue','gmv'],'net platform revenue / gross merchandise value × 100',lambda r,g:r/g*100 if g else None,'%')
    if business_type=='marketplace' or any(k in metrics for k in ('matched_requests','valid_requests')):
        add('marketplace_fill_rate_pct',['matched_requests','valid_requests'],'matched valid requests / total valid requests × 100',lambda m,v:m/v*100 if v else None,'%')
    if business_type=='saas' or any(k in metrics for k in ('subscription_mrr','starting_mrr')):
        add('arr_run_rate',['subscription_mrr'],'current recurring monthly revenue × 12',lambda m:m*12,period_type='monthly',extra=['Annualized current run-rate, not a 12-month revenue forecast; exclude one-time fees.'])
        add('net_revenue_retention_pct',['starting_mrr','expansion_mrr','contraction_mrr','churned_mrr'],
            '(start MRR + expansion - contraction - churned MRR) / start MRR × 100',lambda s,e,c,h:(s+e-c-h)/s*100 if s else None,'%',period_type='monthly')
        add('logo_retention_pct',['retained_customers','starting_customers'],'same-cohort retained customers / starting customers × 100',lambda r,s:r/s*100 if s else None,'%',extra=['Same original cohort; exclude newly acquired customers.'])
    if business_type=='services' or any(k in metrics for k in ('billable_hours','available_hours')):
        add('utilization_pct',['billable_hours','available_hours'],'billable delivery hours / available delivery hours × 100',lambda b,a:b/a*100 if a else None,'%')
    if business_type in ('hardware','manufacturing') or 'bom_per_unit' in metrics:
        add('hardware_variable_unit_cost',['bom_per_unit','warranty_per_unit','other_variable_per_unit'],
            'bill of materials + warranty provision + other variable cost/unit',lambda b,w,o:b+w+o,extra=['Warranty provision is an assumption until supported by returns data. Avoid double-counting these costs.'])
    add('revenue_crosscheck',['paying_customers','units_per_customer','unit_price'],'paying customers × units/customer × net price',lambda c,u,p:c*u*p)
    expected=output['metrics']['revenue_crosscheck'].get('value')
    if expected is not None and get('revenue') is not None:
        if metrics.get('revenue',{}).get('period') in {metrics[k]['period'] for k in ('paying_customers','unit_price')} and metrics.get('revenue',{}).get('currency')==metrics.get('unit_price',{}).get('currency'):
            if abs(Decimal(expected)-get('revenue'))>Decimal('.01'):
                output['warnings'].append({'code':'REVENUE_CONFLICT','reported':fmt(get('revenue')),'calculated':expected,
                                          'message':'Review revenue vs customers × units × price; no values were overwritten.'})
    add('tam_annual',['total_buyers','annual_spend'],'total in-scope buyers × annual spend/buyer',lambda b,s:b*s,extra=['Bottom-up estimate, source year and buyer definition must match.'])
    add('sam_annual',['reachable_buyers','annual_spend'],'serviceable buyers × annual spend/buyer',lambda b,s:b*s,extra=['Reachability is a founder assumption until verified.'])
    add('som_annual',['qualified_leads','sales_conversion_pct','annual_sales_capacity','annual_spend'],
        'min(qualified leads × measured conversion / 100, annual sales capacity) × annual spend',lambda l,c,k,s:min(l*c/100,k)*s,
        extra=['Time horizon is one year; sales capacity, conversion and lead pool must be justified.'])
    # Never synthesize an LTV from an arbitrary churn benchmark.
    reliable=all(get(k) is not None and metrics[k]['basis']=='actual' for k in ('monthly_churn_pct','cohort_months','cohort_size'))
    if reliable and get('cohort_months')>=3 and get('cohort_size')>0:
        add('ltv_illustrative',['monthly_revenue_per_customer','unit_price','unit_variable_cost','monthly_churn_pct'],
            '(monthly revenue/customer × contribution ratio) / monthly churn',lambda a,p,v,c:a*(p-v)/p/(c/100) if p>v and c>0 else None,
            period_type='monthly',extra=['Indicative stationary churn model, not a reliable lifetime forecast; requires representative cohorts.'])
    else: output['metrics']['ltv_illustrative']={'value':None,'missing':['observed cohort size, at least 3 months and observed churn; no fabricated LTV']}
    for name in ('downside','base','upside'):
        s=book.get('scenarios',{}).get(name,{})
        vals=[dec(s.get(k)) for k in ('units','price','variable_cost','fixed_cost')]
        if any(v is None for v in vals): output['scenarios'][name]={'value':None,'status':'requires_explicit_driver_inputs'};continue
        n,p,c,f=vals
        output['scenarios'][name]={'revenue':fmt(n*p),'contribution':fmt(n*(p-c)),'operating_cash_proxy':fmt(n*(p-c)-f),
            'classification':'estimated','inputs':s,'formula':'units × (price - variable cost/unit) - fixed costs',
            'limitation':'Excludes working capital, tax, financing and one-off investment unless explicitly in costs.'}
    return output
