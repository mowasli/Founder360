import os, json, time, secrets, hashlib, threading, re
from pathlib import Path
from datetime import datetime,timezone,timedelta
from contextlib import asynccontextmanager
from collections import defaultdict,deque
from fastapi import FastAPI, Request, Response, HTTPException, Depends, UploadFile, File
from fastapi.responses import FileResponse,HTMLResponse,JSONResponse
from fastapi.staticfiles import StaticFiles
from .storage import Store,uid,digest,now,create_user,verify_password
from .models import *
from .catalog import catalog,QUESTION_MAP,INDICATOR_MAP,VERSION,ROOT
from .adaptive import route
from .finance import calculate,validate_workbook,dec
from .providers import provider_status,public_research_preview,safe_public_url

def create_app(data_dir=None,start_worker=True):
    store=Store(data_dir)
    stop=threading.Event()
    @asynccontextmanager
    async def lifespan(app):
        worker=None
        if start_worker:
            from .worker import worker_loop
            worker=threading.Thread(target=worker_loop,args=(store,stop),daemon=True);worker.start()
        yield
        stop.set()
        if worker:worker.join(timeout=2)
    app=FastAPI(title='Founder360 AI',version='0.1.0',lifespan=lifespan)
    app.state.store=store
    attempts=defaultdict(deque)
    allowed_origins=set(os.getenv('ALLOWED_ORIGINS','http://localhost:8000,http://127.0.0.1:8000').split(','))
    @app.middleware('http')
    async def security(request,call_next):
        if request.method not in ('GET','HEAD','OPTIONS'):
            origin=request.headers.get('origin')
            forwarded_host=request.headers.get('host','')
            same_origins={f'http://{forwarded_host}',f'https://{forwarded_host}'}
            if origin and origin not in allowed_origins|same_origins:return JSONResponse({'detail':'Origin not allowed'},status_code=403)
            length=request.headers.get('content-length')
            if length and int(length)>11*1024*1024:return JSONResponse({'detail':'Request too large'},status_code=413)
        response=await call_next(request)
        response.headers['X-Content-Type-Options']='nosniff'
        response.headers['Referrer-Policy']='same-origin'
        response.headers['Cache-Control']='no-store' if request.url.path.startswith('/api') else 'no-cache'
        response.headers['Permissions-Policy']='camera=(), microphone=(), geolocation=()'
        response.headers['Content-Security-Policy']="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'"
        if store.production:response.headers['Strict-Transport-Security']='max-age=31536000'
        return response

    @app.exception_handler(ValueError)
    async def invalid(request,exc):return JSONResponse({'detail':str(exc)[:250]},status_code=422)

    def throttle(request,group,limit=8):
        key=(request.client.host if request.client else 'unknown',group)
        q=attempts[key];ts=time.time()
        while q and q[0]<ts-60:q.popleft()
        if len(q)>=limit:raise HTTPException(429,'Rate limit; try again in one minute')
        q.append(ts)
        if len(attempts)>10000:
            for k in list(attempts):
                if not attempts[k] or attempts[k][-1]<ts-120:del attempts[k]

    def current(request:Request):
        token=request.cookies.get('f360_session','')
        s=store.one('SELECT s.*,u.org_id,u.role,u.profile,u.id AS uid FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id=? AND s.expires_at>?',(digest(token),time.time()))
        if not s:raise HTTPException(401,'Sign in required')
        if request.method not in ('GET','HEAD','OPTIONS'):
            if not secrets.compare_digest(request.headers.get('X-CSRF-Token',''),s['csrf']):raise HTTPException(403,'CSRF token required')
        profile=store.unpack(s['profile'])
        if profile.get('synthetic_trial') and profile.get('trial_expires_at',0)<time.time():raise HTTPException(401,'Synthetic trial expired')
        return {'id':s['uid'],'org_id':s['org_id'],'role':s['role'],'profile':profile,'csrf':s['csrf']}

    def safe_user(u):
        org=store.one('SELECT * FROM organizations WHERE id=?',(u['org_id'],))
        return {'id':u['id'],'org_id':u['org_id'],'role':u['role'],'profile':u['profile'],'csrf':u['csrf'],
                'brand':store.unpack(org['settings'])}

    def session(user,response):
        token=secrets.token_urlsafe(40);csrf=secrets.token_urlsafe(32)
        ttl=24*3600 if store.unpack(user['profile']).get('synthetic_trial') else 8*3600
        store.run('INSERT INTO sessions VALUES(?,?,?,?)',(digest(token),user['id'],csrf,time.time()+ttl))
        response.set_cookie('f360_session',token,httponly=True,samesite='strict',secure=store.production,max_age=ttl,path='/')
        return safe_user({'id':user['id'],'org_id':user['org_id'],'role':user['role'],'profile':store.unpack(user['profile']),'csrf':csrf})

    def get_startup(sid,u,write=False):
        s=store.one('SELECT * FROM startups WHERE id=? AND org_id=?',(sid,u['org_id']),u['org_id'])
        if not s:raise HTTPException(404,'Startup not found')
        owner=s['owner_id']==u['id']
        if write and not owner:raise HTTPException(403,'Only the founder can change startup data')
        if not owner:
            if not s['share_program']:raise HTTPException(403,'Founder has not shared with the program')
            if u['role']=='mentor':
                assigned=store.one('SELECT mentor_id FROM assignments WHERE startup_id=? AND mentor_id=? AND org_id=?',(sid,u['id'],u['org_id']),u['org_id'])
                if not assigned:raise HTTPException(403,'Startup not assigned to this mentor')
            elif u['role']!='admin':raise HTTPException(403,'No startup permission')
        s['company']=store.unpack(s['payload'])
        return s

    def get_assessment(aid,u,write=False):
        a=store.one('SELECT * FROM assessments WHERE id=? AND org_id=?',(aid,u['org_id']),u['org_id'])
        if not a:raise HTTPException(404,'Assessment not found')
        s=get_startup(a['startup_id'],u,write)
        a['company']=s['company'];a['state_json']=store.unpack(a['state'])
        return a

    def bump(aid,u):
        store.run('UPDATE assessments SET revision=revision+1 WHERE id=? AND org_id=?',(aid,u['org_id']),u['org_id'])

    def answers_for(aid,org):
        return {r['question_id']:store.unpack(r['payload']) for r in store.all('SELECT * FROM answers WHERE assessment_id=? AND org_id=?',(aid,org),org)}

    def detail(a,u):
        aid=a['id'];org=u['org_id']
        evidence=[{**store.unpack(r['payload']),'id':r['id'],'sha256':r['sha256'],'created_at':r['created_at']} for r in store.all('SELECT * FROM evidence WHERE assessment_id=? AND org_id=?',(aid,org),org)]
        reviews={r['criterion_id']:store.unpack(r['payload']) for r in store.all('SELECT * FROM ratings WHERE assessment_id=? AND org_id=?',(aid,org),org)}
        sources=[{**store.unpack(r['payload']),'id':r['id']} for r in store.all('SELECT * FROM sources WHERE assessment_id=? AND org_id=?',(aid,org),org)]
        comments=[{**store.unpack(r['payload']),'id':r['id'],'author_id':r['author_id'],'created_at':r['created_at']} for r in store.all('SELECT * FROM comments WHERE assessment_id=? AND org_id=? ORDER BY created_at',(aid,org),org)]
        tasks=[{**store.unpack(r['payload']),'id':r['id'],'status':r['status']} for r in store.all('SELECT * FROM tasks WHERE assessment_id=? AND org_id=?',(aid,org),org)]
        return {'id':aid,'startup_id':a['startup_id'],'label':a['label'],'company':a['company'],
            'rubric_version':a['rubric_version'],'revision':a['revision'],'state':a['state_json'],
            'created_at':a['created_at'],'answers':answers_for(aid,org),'evidence':evidence,'reviews':reviews,'sources':sources,
            'comments':comments,'tasks':tasks,'has_report':bool(a['report']),
            'report_stale':bool(a['report']) and a['report_revision']!=a['revision'],
            'can_edit':a['company'].get('owner_id')==u['id'] or store.one('SELECT owner_id FROM startups WHERE id=? AND org_id=?',(a['startup_id'],org),org)['owner_id']==u['id']}

    @app.get('/healthz')
    def health():return {'status':'ok','version':'0.1.0'}

    @app.get('/api/v1/catalog')
    def get_catalog():return catalog()

    @app.get('/api/v1/demo')
    def demo(locale:str='ar'):
        from .fixtures import synthetic_snapshot
        from .reports import build_report
        if locale not in ('ar','en'):raise HTTPException(422,'Unsupported locale')
        snapshot=synthetic_snapshot();snapshot['locale']=locale
        return build_report(snapshot,'SYNTHETIC-DEMO')

    @app.get('/api/v1/capabilities')
    def capabilities(u=Depends(current)):
        return {'auth':'local_password_sessions','database':'postgresql' if store.url else 'sqlite_wal',
            'external':provider_status(),'documents':'encrypted_private_files; type validation; no enterprise malware scanner',
            'training':'not_enabled','production_certified':False}

    @app.post('/api/v1/auth/register',status_code=201)
    def register(body:Register,request:Request,response:Response):
        throttle(request,'register',6)
        if not body.processing_consent:raise HTTPException(422,'Processing consent required')
        org=None;role='founder';inv=None
        if body.invite_token:
            inv=store.one('SELECT * FROM invitations WHERE token_hash=? AND used=0 AND expires_at>?',(digest(body.invite_token),time.time()))
            if not inv:raise HTTPException(422,'Invitation invalid or expired')
            if store.run('UPDATE invitations SET used=1 WHERE token_hash=? AND used=0',(digest(body.invite_token),))!=1:raise HTTPException(409,'Invitation already used')
            org=inv['org_id'];role=inv['role']
        try:user=create_user(store,body.email,body.password,body.name,org,role)
        except Exception:
            if inv:store.run('UPDATE invitations SET used=0 WHERE token_hash=?',(digest(body.invite_token),))
            raise
        store.audit(user,user['id'],'account.created.processing_consent_v1')
        return session(user,response)

    @app.post('/api/v1/auth/trial',status_code=201)
    def synthetic_trial(body:dict,request:Request,response:Response):
        if store.production:raise HTTPException(404,'Synthetic trial is disabled in production')
        throttle(request,'trial',3)
        if request.cookies.get('f360_session'):raise HTTPException(409,'Sign out before starting a separate synthetic trial')
        from .fixtures import synthetic_snapshot
        from .reports import build_report
        user=create_user(store,uid()+'@trial.invalid',secrets.token_urlsafe(32),'مؤسس تجريبي · بيانات اصطناعية')
        profile=store.unpack(user['profile']);profile.update({'synthetic_trial':True,'trial_expires_at':time.time()+86400,'locale':body.get('locale') if body.get('locale') in ('ar','en') else 'ar'})
        store.run('UPDATE users SET profile=? WHERE id=?',(store.pack(profile),user['id']))
        user['profile']=store.pack(profile)
        s=synthetic_snapshot();sid=uid();aid=uid();s['company']['share_program']=False
        report=build_report(s,'SYNTHETIC-TRIAL-'+aid[:10])
        with store.connect(user['org_id']) as c:
            c.execute('INSERT INTO startups VALUES(?,?,?,?,?,?)',(sid,user['org_id'],user['id'],store.pack(s['company']),0,now()))
            c.execute('INSERT INTO assessments VALUES(?,?,?,?,?,?,?,?,?,?)',(aid,user['org_id'],sid,VERSION,'baseline',store.pack({'finance':s['finance']}),store.pack(report),0,0,now()))
            for qid,a in s['answers'].items():c.execute('INSERT INTO answers VALUES(?,?,?,?,?)',(user['org_id'],aid,qid,store.pack(a),now()))
            for actions in report['action_plan'].values():
                for action in actions:c.execute('INSERT INTO tasks VALUES(?,?,?,?,?)',(aid+'-'+action['id'],user['org_id'],aid,store.pack(action),'planned'))
        store.audit(user,aid,'synthetic.trial.created.no_real_data')
        return {'user':session(user,response),'assessment_id':aid,'expires_in_hours':24,'synthetic':True}

    @app.post('/api/v1/auth/login')
    def login(body:Login,request:Request,response:Response):
        throttle(request,'login',10)
        user=store.one('SELECT * FROM users WHERE email_hash=?',(digest(body.email.lower()),))
        # Equalize missing-account work to reduce account enumeration timing.
        if not user:
            from .storage import hash_password
            hash_password('dummy-password-for-auth')
        if not user or not verify_password(body.password,user['password']):raise HTTPException(401,'Invalid email or password')
        store.audit(user,user['id'],'account.login')
        return session(user,response)

    @app.get('/api/v1/auth/me')
    def me(u=Depends(current)):return safe_user(u)

    @app.post('/api/v1/auth/logout')
    def logout(request:Request,response:Response,u=Depends(current)):
        store.run('DELETE FROM sessions WHERE id=?',(digest(request.cookies.get('f360_session','')),))
        response.delete_cookie('f360_session',path='/');return {'ok':True}

    @app.patch('/api/v1/auth/preferences')
    def preferences(body:dict,u=Depends(current)):
        if body.get('locale') not in ('ar','en'):raise HTTPException(422,'Invalid locale')
        profile={**u['profile'],'locale':body['locale']}
        store.run('UPDATE users SET profile=? WHERE id=? AND org_id=?',(store.pack(profile),u['id'],u['org_id']))
        return {'profile':profile}

    @app.get('/api/v1/startups')
    def startups(u=Depends(current)):
        if u['role']=='admin':rows=store.all('SELECT * FROM startups WHERE org_id=? AND (share_program=1 OR owner_id=?) ORDER BY created_at DESC',(u['org_id'],u['id']),u['org_id'])
        elif u['role']=='mentor':rows=store.all('SELECT s.* FROM startups s JOIN assignments m ON m.startup_id=s.id WHERE s.org_id=? AND m.mentor_id=? AND s.share_program=1 ORDER BY s.created_at DESC',(u['org_id'],u['id']),u['org_id'])
        else:rows=store.all('SELECT * FROM startups WHERE org_id=? AND owner_id=? ORDER BY created_at DESC',(u['org_id'],u['id']),u['org_id'])
        out=[]
        for s in rows:
            assessments=store.all('SELECT id,label,created_at,rubric_version,revision,report_revision,report FROM assessments WHERE startup_id=? AND org_id=? ORDER BY created_at',(s['id'],u['org_id']),u['org_id'])
            for a in assessments:
                r=store.unpack(a.pop('report'))
                a['overall']=r['overall'] if r else None
            out.append({'id':s['id'],'company':store.unpack(s['payload']),'owner_id':s['owner_id'],'assessments':assessments,'shared':bool(s['share_program'])})
        return {'startups':out}

    @app.post('/api/v1/startups',status_code=201)
    def new_startup(body:Company,u=Depends(current)):
        if u['role']!='founder':raise HTTPException(403,'Founder account required')
        if not body.processing_consent:raise HTTPException(422,'Processing consent required')
        payload=body.model_dump();payload['founder_name']=u['profile']['name'];payload['consent_recorded_at']=now()
        sid=uid()
        store.run('INSERT INTO startups VALUES(?,?,?,?,?,?)',(sid,u['org_id'],u['id'],store.pack(payload),int(body.share_program),now()),u['org_id'])
        store.audit(u,sid,'startup.created.consent_v1')
        return {'id':sid,'company':payload}

    @app.put('/api/v1/startups/{sid}')
    def update_startup(sid:str,body:Company,u=Depends(current)):
        s=get_startup(sid,u,True)
        if not body.processing_consent:raise HTTPException(422,'Use deletion workflow to withdraw processing consent')
        p={**body.model_dump(),'founder_name':u['profile']['name'],'consent_recorded_at':now()}
        with store.connect(u['org_id']) as c:
            c.execute('UPDATE startups SET payload=?,share_program=? WHERE id=? AND org_id=?',(store.pack(p),int(body.share_program),sid,u['org_id']))
            c.execute('UPDATE assessments SET revision=revision+1 WHERE startup_id=? AND org_id=?',(sid,u['org_id']))
            # Reviews must be rechecked if stage, market or the business model changes.
            if any(p.get(k)!=s['company'].get(k) for k in ('stage','country','city','business_type')):
                c.execute('DELETE FROM ratings WHERE org_id=? AND assessment_id IN (SELECT id FROM assessments WHERE startup_id=? AND org_id=?)',(u['org_id'],sid,u['org_id']))
        store.audit(u,sid,'startup.profile_and_consents.updated')
        return {'id':sid,'company':p}

    @app.post('/api/v1/assessments',status_code=201)
    def new_assessment(body:AssessmentCreate,u=Depends(current)):
        get_startup(body.startup_id,u,True)
        aid=uid();state={'finance':{},'cursor':None}
        copied={}
        if body.copy_from:
            previous=get_assessment(body.copy_from,u,True)
            if previous['startup_id']!=body.startup_id:raise HTTPException(422,'Follow-up must be for the same startup')
            state={**previous['state_json'],'copied_from':body.copy_from}
            copied=answers_for(body.copy_from,u['org_id'])
        with store.connect(u['org_id']) as c:
            c.execute('INSERT INTO assessments VALUES(?,?,?,?,?,?,?,?,?,?)',(aid,u['org_id'],body.startup_id,VERSION,body.label,store.pack(state),None,0,None,now()))
            for qid,a in copied.items():
                # Cross-assessment evidence is not implicitly shared; reassess every copied assertion.
                a={**a,'evidence_ids':[],'copied_from':body.copy_from,'review_required':True}
                c.execute('INSERT INTO answers VALUES(?,?,?,?,?)',(u['org_id'],aid,qid,store.pack(a),now()))
        store.audit(u,aid,'assessment.created')
        return {'id':aid}

    @app.get('/api/v1/assessments/{aid}')
    def read_assessment(aid:str,u=Depends(current)):return detail(get_assessment(aid,u),u)

    @app.get('/api/v1/assessments/{aid}/next-questions')
    def next_questions(aid:str,mode:str='first',pillar:str|None=None,u=Depends(current)):
        if mode not in ('first','deep'):raise HTTPException(422,'Invalid mode')
        a=get_assessment(aid,u)
        return route(a['company'],answers_for(aid,u['org_id']),mode,pillar)

    @app.get('/api/v1/assessments/{aid}/questions/{qid}')
    def one_question(aid:str,qid:str,u=Depends(current)):
        get_assessment(aid,u)
        if qid not in QUESTION_MAP:raise HTTPException(404,'Question not found')
        return QUESTION_MAP[qid]

    @app.post('/api/v1/assessments/{aid}/answers')
    def answer(aid:str,body:Answer,u=Depends(current)):
        a=get_assessment(aid,u,True)
        if body.question_id not in QUESTION_MAP:raise HTTPException(422,'Unknown question')
        if body.status=='answered' and not body.text:raise HTTPException(422,'Provide an answer or choose unknown')
        if body.status=='not_applicable' and len(body.reason)<10:raise HTTPException(422,'N/A needs a context reason; it does not automatically remove the criterion')
        if body.share_with_ai and not a['company'].get('external_ai_consent'):raise HTTPException(422,'Separate AI processing consent required')
        for eid in body.evidence_ids:
            if not store.one('SELECT id FROM evidence WHERE id=? AND assessment_id=? AND org_id=?',(eid,aid,u['org_id']),u['org_id']):raise HTTPException(422,'Evidence is outside this assessment')
        if body.status=='answered' and QUESTION_MAP[body.question_id]['input_type']=='number_with_unit_and_period':
            if not body.measurements:raise HTTPException(422,'Numeric answer requires value, unit, period and source; choose unknown if unavailable')
            for m in body.measurements:
                dec(m.get('value'))
                if m.get('value') is None or not all(m.get(k) for k in ('unit','period','source','currency')):raise HTTPException(422,'Missing numeric metadata')
        payload={**body.model_dump(),'classification':'founder_reported','updated_at':now()}
        if body.status!='answered':payload['text']='';payload['measurements']=[]
        with store.connect(u['org_id']) as c:
            c.execute('INSERT INTO answers VALUES(?,?,?,?,?) ON CONFLICT(assessment_id,question_id) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at',(u['org_id'],aid,body.question_id,store.pack(payload),now()))
            c.execute('DELETE FROM ratings WHERE assessment_id=? AND org_id=? AND criterion_id=?',(aid,u['org_id'],QUESTION_MAP[body.question_id]['criterion_id']))
            c.execute('UPDATE assessments SET revision=revision+1 WHERE id=? AND org_id=?',(aid,u['org_id']))
        store.audit(u,aid,'answer.saved.review_invalidated')
        return {'saved':True,'next':route(a['company'],answers_for(aid,u['org_id']))}

    @app.put('/api/v1/assessments/{aid}/finance')
    def finance(aid:str,body:dict,u=Depends(current)):
        a=get_assessment(aid,u,True)
        validate_workbook(body);result=calculate(body,a['company'].get('business_type'))
        state={**a['state_json'],'finance':body}
        store.run('UPDATE assessments SET state=?,revision=revision+1 WHERE id=? AND org_id=?',(store.pack(state),aid,u['org_id']),u['org_id'])
        store.audit(u,aid,'finance.saved')
        return result

    @app.get('/api/v1/assessments/{aid}/finance')
    def finance_read(aid:str,u=Depends(current)):
        a=get_assessment(aid,u);return calculate(a['state_json'].get('finance',{}),a['company'].get('business_type'))

    @app.post('/api/v1/assessments/{aid}/evidence',status_code=201)
    async def upload(aid:str,file:UploadFile=File(...),u=Depends(current)):
        get_assessment(aid,u,True)
        count=store.one('SELECT COUNT(*) AS n FROM evidence WHERE assessment_id=? AND org_id=?',(aid,u['org_id']),u['org_id'])['n']
        if count>=25:raise HTTPException(422,'Maximum 25 evidence files per assessment')
        name=Path(file.filename or 'evidence').name[:150]
        suffix=Path(name).suffix.lower()
        allowed={'.txt':'text/plain','.csv':'text/csv','.json':'application/json','.pdf':'application/pdf','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg'}
        if suffix not in allowed:raise HTTPException(422,'Only PDF, PNG, JPEG, TXT, CSV and JSON; no active documents')
        data=await file.read(10*1024*1024+1)
        if not data or len(data)>10*1024*1024:raise HTTPException(413,'Maximum 10 MB per file')
        if suffix=='.pdf':
            if not data.startswith(b'%PDF-') or any(tag in data.lower() for tag in (b'/javascript',b'/js',b'/launch',b'/embeddedfile',b'/openaction')):raise HTTPException(422,'Invalid PDF or active content detected')
            from pypdf import PdfReader
            import io
            try:
                pdf=PdfReader(io.BytesIO(data))
                if pdf.is_encrypted:raise ValueError('Encrypted PDFs are not accepted')
                if len(pdf.pages)>150:raise ValueError('PDF exceeds page limit')
            except Exception:raise HTTPException(422,'Unreadable, encrypted or oversized PDF')
        elif suffix=='.png' and not data.startswith(b'\x89PNG\r\n\x1a\n'):raise HTTPException(422,'Invalid PNG')
        elif suffix in ('.jpg','.jpeg') and not data.startswith(b'\xff\xd8\xff'):raise HTTPException(422,'Invalid JPEG')
        elif suffix in ('.txt','.csv','.json'):
            try:
                text=data.decode('utf-8')
                if '\x00' in text:raise ValueError()
                if suffix=='.json':json.loads(text)
            except Exception:raise HTTPException(422,'Text must be UTF-8; JSON must be valid')
        # Documents are stored as untrusted bytes; no extraction or model ingestion.
        eid=uid();blob=eid+'.enc'
        path=store.blobs/blob;path.write_bytes(store.cipher.encrypt(data));path.chmod(0o600)
        metadata={'name':name,'content_type':allowed[suffix],'size':len(data),'trust':'untrusted','model_ingestion':False,
                  'scan':'type and active-content checks only; no enterprise antivirus','retention_until':(datetime.now(timezone.utc)+timedelta(days=180)).date().isoformat()}
        store.run('INSERT INTO evidence VALUES(?,?,?,?,?,?,?)',(eid,u['org_id'],aid,store.pack(metadata),blob,hashlib.sha256(data).hexdigest(),now()),u['org_id'])
        bump(aid,u);store.audit(u,eid,'evidence.uploaded.untrusted')
        return {'id':eid,**metadata}

    @app.get('/api/v1/assessments/{aid}/evidence/{eid}')
    def download_evidence(aid:str,eid:str,u=Depends(current)):
        get_assessment(aid,u)
        e=store.one('SELECT * FROM evidence WHERE id=? AND assessment_id=? AND org_id=?',(eid,aid,u['org_id']),u['org_id'])
        if not e:raise HTTPException(404,'Evidence not found')
        m=store.unpack(e['payload']);data=store.cipher.decrypt((store.blobs/e['blob_name']).read_bytes())
        store.audit(u,eid,'evidence.downloaded')
        from urllib.parse import quote
        return Response(data,media_type=m['content_type'],headers={'Content-Disposition':"attachment; filename*=UTF-8''"+quote(m['name'])})

    @app.get('/api/v1/assessments/{aid}/research-preview')
    def research_preview(aid:str,u=Depends(current)):
        a=get_assessment(aid,u);return {**public_research_preview(a['company']),'provider':provider_status()}

    @app.post('/api/v1/assessments/{aid}/sources',status_code=201)
    def add_source(aid:str,body:Source,u=Depends(current)):
        get_assessment(aid,u)
        if not safe_public_url(body.url):raise HTTPException(422,'Public HTTPS URL required; server does not fetch submitted URLs')
        if body.allowed_use=='licensed_excerpt' and not (body.license_url and body.license_checked_at):raise HTTPException(422,'License URL and verification date required')
        for cid in body.conflicts_with:
            if not store.one('SELECT id FROM sources WHERE id=? AND assessment_id=? AND org_id=?',(cid,aid,u['org_id']),u['org_id']):raise HTTPException(422,'Conflict reference outside assessment')
        sid=uid();p={**body.model_dump(),'status':'unverified','checked_at':None,'submitted_at':now(),'id':sid}
        store.run('INSERT INTO sources VALUES(?,?,?,?)',(sid,u['org_id'],aid,store.pack(p)),u['org_id'])
        bump(aid,u);store.audit(u,sid,'source.submitted.unverified')
        return p

    @app.post('/api/v1/assessments/{aid}/sources/{sid}/review')
    def review_source(aid:str,sid:str,body:SourceReview,u=Depends(current)):
        get_assessment(aid,u)
        if u['role'] not in ('admin','mentor'):raise HTTPException(403,'Mentor or administrator review required')
        s=store.one('SELECT * FROM sources WHERE id=? AND assessment_id=? AND org_id=?',(sid,aid,u['org_id']),u['org_id'])
        if not s:raise HTTPException(404,'Source not found')
        p=store.unpack(s['payload'])
        if body.status=='verified' and p.get('match_status')=='nonmatching':raise HTTPException(422,'Nonmatching comparisons cannot be verified')
        if body.status=='verified' and p.get('kind') in ('competitor','analogue') and (not p.get('company_name') or len(p.get('limits',''))<10):raise HTTPException(422,'Company name and limits of comparison required')
        previous=dict(p)
        p.update({'status':body.status,'review_reason':body.reason,'reviewer_id':u['id'],'checked_at':now(),
                  'expires_at':(datetime.now(timezone.utc)+timedelta(days=90)).isoformat()})
        store.run('UPDATE sources SET payload=? WHERE id=? AND org_id=?',(store.pack(p),sid,u['org_id']),u['org_id'])
        store.run('INSERT INTO review_events VALUES(?,?,?,?,?,?)',(uid(),u['org_id'],aid,sid,store.pack({'before':previous,'after':p,'reviewer_id':u['id']}),now()),u['org_id'])
        bump(aid,u);store.audit(u,sid,'source.reviewed.'+body.status);return p

    @app.post('/api/v1/assessments/{aid}/criteria/{cid}/review')
    def review_criterion(aid:str,cid:str,body:Rating,u=Depends(current)):
        get_assessment(aid,u)
        if u['role'] not in ('admin','mentor'):raise HTTPException(403,'Mentor or administrator required')
        if cid not in INDICATOR_MAP:raise HTTPException(422,'Unknown criterion')
        if body.score in (0,2,3,4) and not body.evidence_ids:raise HTTPException(422,'A score of 0 or 2-4 requires attributable evidence')
        if body.score==4 and len(set(body.evidence_ids))<2:raise HTTPException(422,'A repeatably cross-checked score of 4 requires at least two attributable evidence items')
        try:observed=datetime.fromisoformat(body.observed_at[:10]).date()
        except ValueError:raise HTTPException(422,'Valid observation date required')
        if observed>datetime.now(timezone.utc).date():raise HTTPException(422,'Observation cannot be in the future')
        for eid in body.evidence_ids:
            if not store.one('SELECT id FROM evidence WHERE id=? AND assessment_id=? AND org_id=?',(eid,aid,u['org_id']),u['org_id']) and not store.one('SELECT id FROM sources WHERE id=? AND assessment_id=? AND org_id=?',(eid,aid,u['org_id']),u['org_id']):raise HTTPException(422,'Evidence not in assessment')
        p={**body.model_dump(),'reviewer_id':u['id'],'reviewed_at':now()}
        previous=store.one('SELECT payload FROM ratings WHERE assessment_id=? AND criterion_id=? AND org_id=?',(aid,cid,u['org_id']),u['org_id'])
        store.run('INSERT INTO ratings VALUES(?,?,?,?) ON CONFLICT(assessment_id,criterion_id) DO UPDATE SET payload=excluded.payload',(u['org_id'],aid,cid,store.pack(p)),u['org_id'])
        store.run('INSERT INTO review_events VALUES(?,?,?,?,?,?)',(uid(),u['org_id'],aid,cid,store.pack({'before':store.unpack(previous['payload']) if previous else None,'after':p,'reviewer_id':u['id']}),now()),u['org_id'])
        bump(aid,u);store.audit(u,cid,'criterion.reviewed');return p

    @app.post('/api/v1/assessments/{aid}/analyze',status_code=202)
    def analyze(aid:str,body:AnalysisOptions,request:Request,u=Depends(current)):
        throttle(request,'analysis',5)
        a=get_assessment(aid,u,True);d=detail(a,u)
        if body.research and not a['company'].get('external_research_consent'):raise HTTPException(422,'Public research consent required')
        if body.ai and not a['company'].get('external_ai_consent'):raise HTTPException(422,'Separate model processing consent required')
        options=body.model_dump();key=digest(aid+str(a['revision'])+json.dumps(options,sort_keys=True))
        existing=store.one('SELECT id,status,stage FROM jobs WHERE idempotency=? AND org_id=?',(key,u['org_id']),u['org_id'])
        if existing:return existing
        # Expired web sources stay visible but are no longer asserted as verified.
        for s in d['sources']:
            if s.get('status')=='verified' and s.get('expires_at') and s['expires_at']<now():s['status']='unverified';s['freshness']='expired'
        snapshot={'company':a['company'],'answers':d['answers'],'reviews':d['reviews'],'evidence':d['evidence'],
                  'sources':d['sources'],'finance':a['state_json'].get('finance',{}),'locale':body.locale,'created_at':now()}
        jid=uid()
        store.run('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(jid,u['org_id'],aid,store.pack({'snapshot':snapshot,'options':options}),a['revision'],'queued','queued',0,0,key,None,now(),now()),u['org_id'])
        store.audit(u,jid,'analysis.queued');return {'id':jid,'status':'queued','stage':'queued'}

    @app.get('/api/v1/jobs/{jid}')
    def job(jid:str,u=Depends(current)):
        j=store.one('SELECT id,assessment_id,status,stage,attempts,error_code,created_at,updated_at FROM jobs WHERE id=? AND org_id=?',(jid,u['org_id']),u['org_id'])
        if not j:raise HTTPException(404,'Job not found')
        get_assessment(j['assessment_id'],u);return j

    @app.post('/api/v1/jobs/{jid}/retry')
    def retry_job(jid:str,u=Depends(current)):
        j=store.one('SELECT * FROM jobs WHERE id=? AND org_id=?',(jid,u['org_id']),u['org_id'])
        if not j:raise HTTPException(404,'Job not found')
        a=get_assessment(j['assessment_id'],u,True)
        if j['status']!='failed' or j['attempts']>=3:raise HTTPException(422,'Retry unavailable')
        if a['revision']!=j['input_revision']:raise HTTPException(409,'Assessment changed; create a new analysis')
        if store.one('SELECT id FROM provider_calls WHERE job_id=? AND org_id=?',(jid,u['org_id']),u['org_id']):raise HTTPException(409,'External request may have been billed; automatic replay is blocked')
        store.run('UPDATE jobs SET status=?,stage=?,error_code=NULL,lease_until=0 WHERE id=? AND org_id=?',('queued','queued',jid,u['org_id']),u['org_id'])
        return {'id':jid,'status':'queued'}

    @app.get('/api/v1/assessments/{aid}/report')
    def get_report(aid:str,u=Depends(current)):
        a=get_assessment(aid,u)
        if not a['report']:raise HTTPException(404,'Report not generated')
        report=report_with_tasks(a,u)
        store.audit(u,aid,'report.read')
        return {'report':report,'stale':a['report_revision']!=a['revision']}

    @app.get('/api/v1/assessments/{aid}/history')
    def report_history(aid:str,u=Depends(current)):
        get_assessment(aid,u)
        versions=store.all('SELECT id,revision,created_at FROM report_versions WHERE assessment_id=? AND org_id=? ORDER BY created_at DESC',(aid,u['org_id']),u['org_id'])
        events=store.all('SELECT * FROM review_events WHERE assessment_id=? AND org_id=? ORDER BY created_at DESC',(aid,u['org_id']),u['org_id'])
        return {'report_versions':versions,'review_events':[{**r,'payload':store.unpack(r['payload'])} for r in events]}

    @app.get('/api/v1/assessments/{aid}/history/{rid}')
    def historic_report(aid:str,rid:str,u=Depends(current)):
        get_assessment(aid,u)
        row=store.one('SELECT payload FROM report_versions WHERE id=? AND assessment_id=? AND org_id=?',(rid,aid,u['org_id']),u['org_id'])
        if not row:raise HTTPException(404,'Report version not found')
        return store.unpack(row['payload'])

    def report_with_tasks(a,u):
        report=store.unpack(a['report'])
        tasks={r['id']:r for r in store.all('SELECT * FROM tasks WHERE assessment_id=? AND org_id=?',(a['id'],u['org_id']),u['org_id'])}
        for actions in report['action_plan'].values():
            for action in actions:
                r=tasks.get(a['id']+'-'+action['id'])
                if r:
                    payload=store.unpack(r['payload'])
                    action.update({k:payload[k] for k in ('owner','note','updated_at') if k in payload});action['status']=r['status']
        return report

    @app.get('/api/v1/assessments/{aid}/report.json')
    def report_json(aid:str,u=Depends(current)):
        a=get_assessment(aid,u)
        if not a['report']:raise HTTPException(404,'Report not generated')
        store.audit(u,aid,'report.exported.json')
        return Response(json.dumps(report_with_tasks(a,u),ensure_ascii=False,indent=2),media_type='application/json',headers={'Content-Disposition':'attachment; filename="Founder360-report.json"'})

    @app.get('/api/v1/assessments/{aid}/report.html',response_class=HTMLResponse)
    def report_html(aid:str,u=Depends(current)):
        a=get_assessment(aid,u)
        if not a['report']:raise HTTPException(404,'Report not generated')
        from .exporter import html_report
        return html_report(report_with_tasks(a,u),a['report_revision']!=a['revision'])

    @app.get('/api/v1/assessments/{aid}/report.pdf')
    def pdf(aid:str,u=Depends(current)):
        a=get_assessment(aid,u)
        if not a['report']:raise HTTPException(404,'Report not generated')
        from .exporter import pdf_report
        store.audit(u,aid,'report.exported.pdf')
        return Response(pdf_report(report_with_tasks(a,u),a['report_revision']!=a['revision']),media_type='application/pdf',headers={'Content-Disposition':'attachment; filename="Founder360-diagnostic.pdf"'})

    @app.post('/api/v1/assessments/{aid}/mentor-comments',status_code=201)
    def add_comment(aid:str,body:Comment,u=Depends(current)):
        get_assessment(aid,u)
        cid=uid()
        store.run('INSERT INTO comments VALUES(?,?,?,?,?,?)',(cid,u['org_id'],aid,u['id'],store.pack({**body.model_dump(),'author_name':u['profile']['name'],'role':u['role']}),now()),u['org_id'])
        store.audit(u,aid,'mentor_comment.added');return {'id':cid}

    @app.patch('/api/v1/assessments/{aid}/tasks/{tid}')
    def update_task(aid:str,tid:str,body:TaskUpdate,u=Depends(current)):
        get_assessment(aid,u)
        t=store.one('SELECT * FROM tasks WHERE id=? AND assessment_id=? AND org_id=?',(tid,aid,u['org_id']),u['org_id'])
        if not t:raise HTTPException(404,'Task not found')
        p=store.unpack(t['payload']);p.update({'note':body.note,'updated_by':u['id'],'updated_at':now()})
        if body.owner:p['owner']=body.owner
        store.run('UPDATE tasks SET payload=?,status=? WHERE id=? AND org_id=?',(store.pack(p),body.status,tid,u['org_id']),u['org_id'])
        store.audit(u,tid,'task.'+body.status);return {**p,'status':body.status}

    @app.get('/api/v1/startups/{sid}/comparison')
    def comparison(sid:str,baseline:str,followup:str,u=Depends(current)):
        get_startup(sid,u)
        a=get_assessment(baseline,u);b=get_assessment(followup,u)
        if a['startup_id']!=sid or b['startup_id']!=sid:raise HTTPException(422,'Comparison must be within the same startup')
        if not a['report'] or not b['report']:raise HTTPException(422,'Generate both reports first')
        r1=store.unpack(a['report']);r2=store.unpack(b['report'])
        compatible=a['rubric_version']==b['rubric_version'] and r1['overall']['rules_version']==r2['overall']['rules_version']
        # Context changes also change applicability and comparability.
        context_changed=any(r1['company'].get(k)!=r2['company'].get(k) for k in ('stage','business_type','country','city'))
        p1={p['id']:p for p in r1['pillars']};out=[]
        for p in r2['pillars']:
            old=p1[p['id']];same=compatible and not context_changed and old['applicable']==p['applicable']
            out.append({'id':p['id'],'name_ar':p['name_ar'],'name_en':p['name_en'],'baseline':old['score'],'followup':p['score'],
                'delta':round(p['score']-old['score'],2) if same and old['score'] is not None and p['score'] is not None else None})
        return {'compatible':compatible and not context_changed,'context_changed':context_changed,'baseline_version':a['rubric_version'],'followup_version':b['rubric_version'],
                'stale_reports':a['revision']!=a['report_revision'] or b['revision']!=b['report_revision'],'pillars':out,
                'baseline_overall':r1['overall'],'followup_overall':r2['overall'],'limitation':'Within-startup change, not causal program impact.'}

    @app.get('/api/v1/startups/{sid}/export')
    def export_data(sid:str,u=Depends(current)):
        s=get_startup(sid,u,True)
        rows=store.all('SELECT id FROM assessments WHERE startup_id=? AND org_id=?',(sid,u['org_id']),u['org_id'])
        records=[]
        for row in rows:
            a=get_assessment(row['id'],u);d=detail(a,u);d['report']=report_with_tasks(a,u) if a['report'] else None
            d['report_versions']=[{**r,'payload':store.unpack(r['payload'])} for r in store.all('SELECT * FROM report_versions WHERE assessment_id=? AND org_id=?',(a['id'],u['org_id']),u['org_id'])]
            d['review_events']=[{**r,'payload':store.unpack(r['payload'])} for r in store.all('SELECT * FROM review_events WHERE assessment_id=? AND org_id=?',(a['id'],u['org_id']),u['org_id'])]
            records.append(d)
        store.audit(u,sid,'startup.data_exported')
        return Response(json.dumps({'company':s['company'],'assessments':records,'exported_at':now(),'files':'Download original evidence through authorized evidence links before deletion.'},ensure_ascii=False,indent=2),media_type='application/json',headers={'Content-Disposition':'attachment; filename="Founder360-company-data.json"'})

    @app.delete('/api/v1/startups/{sid}/data')
    def delete_data(sid:str,u=Depends(current)):
        get_startup(sid,u,True)
        rows=store.all('SELECT e.blob_name FROM evidence e JOIN assessments a ON a.id=e.assessment_id WHERE a.startup_id=? AND e.org_id=?',(sid,u['org_id']),u['org_id'])
        store.run('DELETE FROM startups WHERE id=? AND org_id=?',(sid,u['org_id']),u['org_id'])
        for r in rows:(store.blobs/r['blob_name']).unlink(missing_ok=True)
        store.audit(u,sid,'startup.deleted.metadata_only_audit_retained')
        return {'deleted':True,'retained':'Non-content audit event and provider accounting only; backups expire under operator policy.'}

    @app.get('/api/v1/admin/members')
    def members(u=Depends(current)):
        if u['role']!='admin':raise HTTPException(403,'Administrator required')
        rows=store.all('SELECT id,role,profile FROM users WHERE org_id=?',(u['org_id'],))
        return {'members':[{'id':r['id'],'role':r['role'],'name':store.unpack(r['profile'])['name']} for r in rows]}

    @app.post('/api/v1/admin/invitations')
    def invite(body:Invite,u=Depends(current)):
        if u['role']!='admin':raise HTTPException(403,'Administrator required')
        token=secrets.token_urlsafe(32)
        store.run('INSERT INTO invitations VALUES(?,?,?,?,0)',(digest(token),u['org_id'],body.role,time.time()+7*86400))
        store.audit(u,u['org_id'],'invitation.created.'+body.role)
        return {'token':token,'role':body.role,'expires_in_days':7}

    @app.post('/api/v1/admin/startups/{sid}/assign/{mentor_id}')
    def assign(sid:str,mentor_id:str,u=Depends(current)):
        if u['role']!='admin':raise HTTPException(403,'Administrator required')
        get_startup(sid,u)
        if not store.one('SELECT id FROM users WHERE id=? AND org_id=? AND role=?',(mentor_id,u['org_id'],'mentor')):raise HTTPException(422,'Mentor must be in this program')
        store.run('INSERT INTO assignments VALUES(?,?,?) ON CONFLICT(startup_id,mentor_id) DO NOTHING',(u['org_id'],sid,mentor_id),u['org_id'])
        store.audit(u,sid,'mentor.assigned');return {'assigned':True}

    @app.put('/api/v1/admin/brand')
    def branding(body:Brand,u=Depends(current)):
        if u['role']!='admin':raise HTTPException(403,'Administrator required')
        if body.logo_url and not body.logo_url.startswith(('data:image/png;base64,','data:image/jpeg;base64,','/assets/')):raise HTTPException(422,'Use a PNG/JPEG data URL or a local asset path')
        store.run('UPDATE organizations SET settings=? WHERE id=?',(store.pack(body.model_dump()),u['org_id']))
        store.audit(u,u['org_id'],'brand.updated');return body.model_dump()

    @app.get('/api/v1/admin/audit')
    def audit(u=Depends(current)):
        if u['role']!='admin':raise HTTPException(403,'Administrator required')
        return {'events':store.all('SELECT * FROM audit_logs WHERE org_id=? ORDER BY created_at DESC LIMIT 150',(u['org_id'],),u['org_id'])}

    @app.get('/metrics')
    def metrics(u=Depends(current)):
        if u['role']!='admin':raise HTTPException(403,'Administrator required')
        return {'jobs':store.all('SELECT status,COUNT(*) AS count FROM jobs WHERE org_id=? GROUP BY status',(u['org_id'],),u['org_id']),
                'provider_reservations':store.all('SELECT period,SUM(reserved_usd) AS reserved_usd,COUNT(*) AS calls FROM provider_calls WHERE org_id=? GROUP BY period',(u['org_id'],),u['org_id'])}

    dist=ROOT/'dist'
    app.mount('/assets',StaticFiles(directory=dist/'assets',check_dir=False),name='assets')
    fonts=ROOT/'frontend/public/fonts'
    app.mount('/fonts',StaticFiles(directory=fonts),name='fonts')
    @app.get('/{path:path}')
    def spa(path:str):
        if path.startswith(('api/','metrics','healthz')):raise HTTPException(404,'Endpoint not found')
        if (dist/'index.html').exists():return FileResponse(dist/'index.html')
        return HTMLResponse('Build the frontend with npm ci && npm run build.',status_code=503)
    return app
