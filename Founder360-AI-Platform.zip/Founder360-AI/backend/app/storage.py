"""Encrypted payloads, durable local DB, optional PostgreSQL and scoped transactions."""
import os, json, sqlite3, threading, secrets, hashlib, time
from pathlib import Path
from contextlib import contextmanager
from cryptography.fernet import Fernet

SCHEMA = '''
CREATE TABLE IF NOT EXISTS organizations(id TEXT PRIMARY KEY, name TEXT NOT NULL, settings TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, org_id TEXT NOT NULL REFERENCES organizations(id), email_hash TEXT UNIQUE NOT NULL, profile TEXT NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('founder','mentor','admin')), created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, csrf TEXT NOT NULL, expires_at DOUBLE PRECISION NOT NULL);
CREATE TABLE IF NOT EXISTS startups(id TEXT PRIMARY KEY, org_id TEXT NOT NULL REFERENCES organizations(id), owner_id TEXT NOT NULL REFERENCES users(id), payload TEXT NOT NULL, share_program INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS assignments(org_id TEXT NOT NULL, startup_id TEXT NOT NULL REFERENCES startups(id) ON DELETE CASCADE, mentor_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, PRIMARY KEY(startup_id,mentor_id));
CREATE TABLE IF NOT EXISTS assessments(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, startup_id TEXT NOT NULL REFERENCES startups(id) ON DELETE CASCADE, rubric_version TEXT NOT NULL, label TEXT NOT NULL, state TEXT NOT NULL, report TEXT, revision INTEGER NOT NULL DEFAULT 0, report_revision INTEGER, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS answers(org_id TEXT NOT NULL, assessment_id TEXT NOT NULL REFERENCES assessments(id) ON DELETE CASCADE, question_id TEXT NOT NULL, payload TEXT NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY(assessment_id,question_id));
CREATE TABLE IF NOT EXISTS evidence(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, assessment_id TEXT NOT NULL REFERENCES assessments(id) ON DELETE CASCADE, payload TEXT NOT NULL, blob_name TEXT NOT NULL, sha256 TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS ratings(org_id TEXT NOT NULL, assessment_id TEXT NOT NULL REFERENCES assessments(id) ON DELETE CASCADE, criterion_id TEXT NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(assessment_id,criterion_id));
CREATE TABLE IF NOT EXISTS sources(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, assessment_id TEXT NOT NULL REFERENCES assessments(id) ON DELETE CASCADE, payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, assessment_id TEXT NOT NULL REFERENCES assessments(id) ON DELETE CASCADE, payload TEXT NOT NULL, status TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS comments(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, assessment_id TEXT NOT NULL REFERENCES assessments(id) ON DELETE CASCADE, author_id TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS report_versions(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, assessment_id TEXT NOT NULL REFERENCES assessments(id) ON DELETE CASCADE, revision INTEGER NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS review_events(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, assessment_id TEXT NOT NULL REFERENCES assessments(id) ON DELETE CASCADE, entity_id TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, assessment_id TEXT NOT NULL REFERENCES assessments(id) ON DELETE CASCADE, payload TEXT NOT NULL, input_revision INTEGER NOT NULL, status TEXT NOT NULL, stage TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, lease_until DOUBLE PRECISION NOT NULL DEFAULT 0, idempotency TEXT UNIQUE NOT NULL, error_code TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit_logs(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, actor_id TEXT NOT NULL, entity_id TEXT NOT NULL, action TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS provider_calls(id TEXT PRIMARY KEY, org_id TEXT NOT NULL, job_id TEXT NOT NULL, period TEXT NOT NULL, reserved_usd DOUBLE PRECISION NOT NULL, status TEXT NOT NULL, usage TEXT);
CREATE TABLE IF NOT EXISTS invitations(token_hash TEXT PRIMARY KEY, org_id TEXT NOT NULL, role TEXT NOT NULL, expires_at DOUBLE PRECISION NOT NULL, used INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS ix_startups_org ON startups(org_id);
CREATE INDEX IF NOT EXISTS ix_assessments_startup ON assessments(startup_id);
CREATE INDEX IF NOT EXISTS ix_jobs_pending ON jobs(status,lease_until);
'''

def now():
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()

def uid(): return secrets.token_hex(16)
def digest(s): return hashlib.sha256(s.encode()).hexdigest()

class PgAdapter:
    def __init__(self,c): self.c=c
    def execute(self,sql,args=()): return self.c.execute(sql.replace('?','%s'),args)
    def commit(self): self.c.commit()
    def rollback(self): self.c.rollback()
    def close(self): self.c.close()

class Store:
    def __init__(self,data_dir=None):
        self.root=Path(data_dir or os.getenv('FOUNDER360_DATA_DIR','.data')).resolve()
        self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.blobs=self.root/'evidence';self.blobs.mkdir(exist_ok=True,mode=0o700)
        self.url=os.getenv('DATABASE_URL','')
        self.lock=threading.RLock()
        key=os.getenv('DATA_ENCRYPTION_KEY')
        self.production=os.getenv('APP_ENV')=='production'
        if not key:
            if self.production: raise RuntimeError('Production requires DATA_ENCRYPTION_KEY')
            path=self.root/'encryption.key'
            if not path.exists():
                fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
                with os.fdopen(fd,'wb') as f:f.write(Fernet.generate_key())
            key=path.read_bytes()
        self.cipher=Fernet(key)
        with self.connect() as c:
            if self.url:
                for s in SCHEMA.split(';'):
                    if s.strip():c.execute(s)
            else:c.executescript(SCHEMA)

    def pack(self,obj):return self.cipher.encrypt(json.dumps(obj,ensure_ascii=False,allow_nan=False).encode()).decode()
    def unpack(self,payload):return json.loads(self.cipher.decrypt(payload.encode())) if payload else None

    @contextmanager
    def connect(self,org_id=None):
        with self.lock:
            if self.url:
                import psycopg
                from psycopg.rows import dict_row
                c=PgAdapter(psycopg.connect(self.url,row_factory=dict_row))
                if org_id:c.execute("SELECT set_config('app.org_id', ?, true)",(org_id,))
            else:
                c=sqlite3.connect(self.root/'founder360.sqlite3',timeout=30)
                c.row_factory=sqlite3.Row
                c.execute('PRAGMA foreign_keys=ON')
                c.execute('PRAGMA journal_mode=WAL')
            try:
                yield c
                c.commit()
            except Exception:
                c.rollback();raise
            finally:c.close()

    def one(self,sql,args=(),org_id=None):
        with self.connect(org_id) as c:
            r=c.execute(sql,args).fetchone();return dict(r) if r else None
    def all(self,sql,args=(),org_id=None):
        with self.connect(org_id) as c:return [dict(r) for r in c.execute(sql,args).fetchall()]
    def run(self,sql,args=(),org_id=None):
        with self.connect(org_id) as c:return c.execute(sql,args).rowcount
    def audit(self,user,entity,action):
        self.run('INSERT INTO audit_logs VALUES(?,?,?,?,?,?)',(uid(),user['org_id'],user['id'],entity,action,now()),user['org_id'])

def hash_password(password):
    if not isinstance(password,str) or not 12<=len(password)<=256:raise ValueError('Password must contain 12-256 characters')
    salt=secrets.token_bytes(16)
    h=hashlib.scrypt(password.encode(),salt=salt,n=16384,r=8,p=1)
    return salt.hex()+':'+h.hex()

def verify_password(password,encoded):
    try:
        salt,expected=encoded.split(':')
        h=hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt),n=16384,r=8,p=1)
        return secrets.compare_digest(h.hex(),expected)
    except (ValueError,AttributeError):return False

def create_user(store,email,password,name,org_id=None,role='founder'):
    from fastapi import HTTPException
    email=email.strip().lower()
    if not 3<=len(email)<=254 or '@' not in email: raise ValueError('Valid email required')
    password_hash=hash_password(password)
    user_id=uid()
    with store.connect(org_id) as c:
        if c.execute('SELECT id FROM users WHERE email_hash=?',(digest(email),)).fetchone():raise HTTPException(409,'Account already exists')
        if not org_id:
            org_id=uid()
            c.execute('INSERT INTO organizations VALUES(?,?,?)',(org_id,'Founder workspace',store.pack({'brand_name':'Founder360 AI','accent':'#245b45','logo_url':'','locale':'ar'})))
        c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,?)',(user_id,org_id,digest(email),store.pack({'email':email,'name':name,'locale':'ar'}),password_hash,role,now()))
    return store.one('SELECT * FROM users WHERE id=?',(user_id,))
