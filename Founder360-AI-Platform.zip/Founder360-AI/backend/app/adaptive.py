"""Bounded, stable first-pass routing and targeted deepening, independent of LLMs."""
from .catalog import QUESTIONS, QUESTION_MAP, PILLARS, STAGES

def eligible(q, company):
    if STAGES.index(q['stage_from']) > STAGES.index(company['stage']): return False
    if not company.get('has_users') and q['id'] in {'TRACTION_02','TRACTION_03','TRACTION_04','UNIT_ECON_03','UNIT_ECON_05','UNIT_ECON_06'}: return False
    return True

def first_pass(company):
    pool=[q for q in QUESTIONS if eligible(q,company)]
    chosen=[]
    for p in PILLARS:
        choices=[q for q in pool if q['pillar_id']==p['id']]
        if choices: chosen.append(choices[0]['id'])
    priorities=['problem','customers','value','market','business_model','pricing','competition','finance']
    if company.get('has_revenue'): priorities=['unit_econ','finance','traction','sales']+priorities
    if company.get('business_type')=='marketplace': priorities=['business_model','operations','unit_econ']+priorities
    if company.get('business_type')=='saas': priorities=['product','traction','technology']+priorities
    if company.get('business_type')=='services': priorities=['operations','pricing','team']+priorities
    if company.get('sector') in ('fintech','healthtech'): priorities=['regulatory','technology']+priorities
    if company.get('infrastructure_constrained'): priorities=['operations','resilience']+priorities
    # Round-robin after coverage ensures all 20 topics are represented, then 16 useful additions.
    priority=list(dict.fromkeys(priorities+[p['id'] for p in PILLARS]))
    for round_no in range(1,7):
        for pillar in priority:
            options=[q for q in pool if q['pillar_id']==pillar and q['id'] not in chosen]
            if options: chosen.append(options[0]['id'])
            if len(chosen)>=36: return chosen
    return chosen

def route(company, answers, mode='first', pillar=None):
    chosen=first_pass(company)
    if mode=='deep':
        applicable=[q for q in QUESTIONS if eligible(q,company) and (not pillar or q['pillar_id']==pillar)]
        # Prefer an unrepresented indicator, then high-weight uncertain pillars.
        covered={QUESTION_MAP[q]['criterion_id'] for q,a in answers.items() if q in QUESTION_MAP and a.get('status')=='answered'}
        weights={p['id']:p['base_weight_pct'] for p in PILLARS}
        applicable.sort(key=lambda q:(q['criterion_id'] in covered, -weights[q['pillar_id']],q['id']))
        chosen=list(dict.fromkeys(chosen+[q['id'] for q in applicable]))[:100]
    pending=[QUESTION_MAP[q] for q in chosen if q not in answers]
    return {'question':pending[0] if pending else None,'pending':pending[:3],
            'total':len(chosen),'completed':sum(q in answers for q in chosen),'question_ids':chosen,
            'remaining':len(pending),'first_pass_total':len(first_pass(company)),'mode':mode}
