import unittest,io,re
from pypdf import PdfReader
from backend.app.fixtures import synthetic_snapshot
from backend.app.reports import build_report
from backend.app.exporter import pdf_report,html_report

class ExportTests(unittest.TestCase):
 def test_full_arabic_pdf_has_fonts_latin_references_and_links(self):
  r=build_report(synthetic_snapshot());data=pdf_report(r);p=PdfReader(io.BytesIO(data))
  self.assertGreaterEqual(len(p.pages),10)
  text='\n'.join(page.extract_text() for page in p.pages)
  self.assertIn('Founder360 AI',text);self.assertIn('YER',text);self.assertIn('PROBLEM_C01',text);self.assertIn('RESILIENCE_C05',text)
  self.assertTrue(any(page.get('/Annots') for page in p.pages))
  self.assertTrue(any(re.search('[\u0600-\u06ff\ufb50-\ufeff]',page.extract_text()) for page in p.pages))
 def test_english_pdf_and_json_safe_html(self):
  s=synthetic_snapshot();s['locale']='en';s['answers']['PROBLEM_01']['text']='<script>alert("data not executable")</script>'
  r=build_report(s);html=html_report(r)
  self.assertNotIn('<script>',html);self.assertIn('&lt;script&gt;',html)
  p=PdfReader(io.BytesIO(pdf_report(r)))
  self.assertIn('Decision brief','\n'.join(page.extract_text() for page in p.pages))
if __name__=='__main__':unittest.main()
