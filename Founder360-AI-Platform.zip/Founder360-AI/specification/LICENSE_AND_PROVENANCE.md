# Provenance and licensing notes

All methodology texts, question wording, schemas and code in this package were authored for this request on 2026-11-12. External reports/templates/books are **not bundled**. Their URLs are provided only as external reading/data-access pointers, and use is subject to their independent licenses. No proprietary IdeaProof research data or report pages are reproduced.

The startup example is intentionally synthetic, explicitly identified in each file. Financial numbers in it are not assertions about any actual company or region. The scoring rubric is a configurable prototype, not a scientifically validated predictor of startup success. The package does not contain real founder personal information.
