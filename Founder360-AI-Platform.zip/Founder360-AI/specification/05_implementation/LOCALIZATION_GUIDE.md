# Localization guide

- Support full interface Arabic RTL and English LTR; language picker persists per account.
- The 140 question records include both `question_ar` and `question_en`. Keep IDs stable and never translate metric variable names.
- For Arabic render ٠-٩ digits optional UI preference; store decimal numbers with a canonical numeric type and ISO currency; avoid mixed-direction punctuation around URLs.
- Right-align labels, but keep tables with monetary units and formulas readable and accessible.
- Format currency with ISO 4217, show FX date and source if comparison involves exchange rates.
- Never auto-translate customer quotations as if original; label translations.
- Permit local examples in Yemen, Egypt, Saudi Arabia, the Levant, North Africa and other markets based on the **founder's** target, not the incubator's country.
