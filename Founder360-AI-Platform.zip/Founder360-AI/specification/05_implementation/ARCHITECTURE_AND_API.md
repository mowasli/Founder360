# Architecture & API baseline

## Logical components
Frontend bilingual responsive React/Next.js; data collection forms; profile; evidence upload; report viewer; mentor console. Auth/tenant service; Postgres with tenant-level row security; private object store; asynchronous research/analysis queue; provider-agnostic LLM gateway; source resolver and license-aware RAG index; audited deterministic financial/scoring engine; report renderer and job monitor.

## Storage entities
organizations(id,name,settings); users(id,org_id,role); startups(id,org_id,owner_id,stage,sector,country,city,currency,consent_status); assessments(id,startup_id,rubric_version,started_at,completed_at,status); answers(id,assessment_id,question_id,response_json,confidence,self_reported_at); evidence(id,assessment_id,file_uri,sha256,access_policy,retention_date,redaction_status); sources(id,url,title,published_at,checked_at,allowed_use,access_scope); claims(id,assessment_id,classification,text,source_ids,confidence); pillars(id,assessment_id,pillar_id,score,applicable,reasoning); experiments(id,assessment_id,hypothesis,pass_rule,fail_rule,owner,status,due_date); reports(id,assessment_id,report_json_uri,pdf_uri,status); audit_logs(id,actor,tenant,entity,action,timestamp).

## REST API contract outline
POST /api/v1/assessments -> draft for authorized startup
GET /api/v1/assessments/:id -> state + progress
GET /api/v1/assessments/:id/next-questions -> adaptive queue
POST /api/v1/assessments/:id/answers -> validated answer submission
POST /api/v1/assessments/:id/evidence -> presigned private upload URL only
POST /api/v1/assessments/:id/analyze -> idempotent analysis job
GET /api/v1/jobs/:job_id -> status, bounded stage names, safe errors
GET /api/v1/assessments/:id/report -> report_json schema
GET /api/v1/assessments/:id/report.pdf -> authorized export
GET /api/v1/startups/:id/comparison?baseline=:id&followup=:id -> delta with rubric compatibility
POST /api/v1/assessments/:id/mentor-comments -> role-scoped comment
DELETE /api/v1/startups/:id/data -> deletion workflow with retention exceptions
GET /healthz -> basic health check; protected /metrics -> operational monitoring

## Security and deployment
Server-side keys only; narrow CORS, rate limits; passwordless/OIDC if available; tenant checks in every data-layer query; malware scans; attachments stripped of macros/executable content; signed URL expiry; redaction before LLM; prompt injection isolation; budget caps; backups, restore drills; signed PDF audit metadata. Secure deletion and policy alignment by jurisdiction. API calls to external models must have documented retention policies and user consent.

## Real world build requirement
Use true durable database and auth before presenting as production-ready. If external research API is unavailable, UI must mark 'external research not run'; avoid mocked cited results being presented as verified. Tests need stage routing, role leakage, hidden secrets, source expiry, Arabic PDF fidelity, and missing financial input.
