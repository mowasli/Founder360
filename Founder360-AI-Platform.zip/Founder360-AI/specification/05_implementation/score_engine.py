"""Founder360: deterministic evidence-aware scoring. No AI-generated arithmetic.
Run: python score_engine.py or python -m unittest discover -s ../06_tests
"""
from math import isfinite

def compute_diagnostic(pillars, min_coverage=.60, min_pillars=10):
    """pillars = [{id, weight, applicable=True, score: 0..4 or None}]
    score reflects evidence/viability against defined anchors, not probability of success.
    Exclude true N/A from denominator; count unknown applicable in denominator.
    """
    keys=[p.get('id') for p in pillars]
    if len(keys)!=len(set(keys)): raise ValueError('Duplicate pillar id')
    relevant=[p for p in pillars if p.get('applicable',True)]
    for p in relevant:
        w=p.get('weight')
        if not isinstance(w,(int,float)) or not isfinite(w) or w<=0: raise ValueError('Weights must be positive finite')
        s=p.get('score')
        if s is not None and (not isinstance(s,(int,float)) or not isfinite(s) or not 0<=s<=4):
            raise ValueError('score out of 0-4 range')
    total_weight=sum(p['weight'] for p in relevant)
    if total_weight<=0: return {'status':'insufficient_evidence','overall_score':None,'coverage':0}
    scored=[p for p in relevant if p.get('score') is not None]
    known_weight=sum(p['weight'] for p in scored)
    coverage=known_weight/total_weight
    enough=coverage>=min_coverage and len(scored)>=min_pillars
    weighted=sum(p['weight']*p['score']/4 for p in scored)
    score=round(100*weighted/known_weight,1) if enough else None
    return {'status':'scored' if enough else 'insufficient_evidence', 'overall_score':score,
            'evidence_coverage_pct':round(100*coverage,1),'pillars_scored':len(scored),
            'pillars_applicable':len(relevant), 'interpretation':'diagnostic evidence/readiness score, NOT probability of success'}

def compute_pillar_score(criteria, min_coverage=.60):
    """Each criterion has weight and score 0..4 / None, true N/A excluded.
    Keep 'unknown' separate and withhold score when <60% applicable evidence coverage.
    """
    relevant=[c for c in criteria if c.get('applicable',True)]
    total=sum(c.get('weight',1) for c in relevant)
    if total<=0: return {'score':None,'coverage_pct':0.0,'status':'not_applicable'}
    known=[c for c in relevant if c.get('score') is not None]
    for c in relevant:
        value=c.get('score'); weight=c.get('weight',1)
        if not isinstance(weight,(int,float)) or not isfinite(weight) or weight<=0: raise ValueError('invalid weight')
        if value is not None and (not isinstance(value,(int,float)) or not isfinite(value) or not 0<=value<=4): raise ValueError('invalid score')
    available=sum(c.get('weight',1) for c in known)
    coverage=available/total
    if coverage<min_coverage: return {'score':None,'coverage_pct':round(coverage*100,1),'status':'insufficient_evidence'}
    return {'score':round(sum(c.get('weight',1)*c['score'] for c in known)/available,2),
            'coverage_pct':round(coverage*100,1),'status':'scored'}

def unit_economics(revenue_per_unit=None,variable_cost_per_unit=None,acquisition_spend=None,new_paying_customers=None):
    out={}
    if revenue_per_unit is not None and variable_cost_per_unit is not None:
        if revenue_per_unit<0 or variable_cost_per_unit<0: raise ValueError('Negative values invalid')
        out['contribution_per_unit']=round(revenue_per_unit-variable_cost_per_unit,2)
        out['contribution_margin_pct']=round((revenue_per_unit-variable_cost_per_unit)/revenue_per_unit*100,2) if revenue_per_unit>0 else None
    if acquisition_spend is not None and new_paying_customers is not None:
        if acquisition_spend<0 or new_paying_customers<0: raise ValueError('Negative values invalid')
        out['cac']=round(acquisition_spend/new_paying_customers,2) if new_paying_customers>0 else None
    return out

def runway_months(cash_balance,monthly_net_burn):
    if cash_balance<0: raise ValueError('cash cannot be negative')
    if monthly_net_burn is None or monthly_net_burn<=0: return None
    return round(cash_balance/monthly_net_burn,2)

if __name__=='__main__':
    print(compute_diagnostic([{'id':str(i),'weight':5,'score':(3 if i<14 else None)} for i in range(20)]))
