# Founder worksheets (original templates)

## A. Assumption log
| فرضية | لماذا مهمة؟ | دليل يؤيد/ينفي | اختبار خلال 14 يومًا | المقياس | قرار إذا فشلت |
|---|---|---|---|---|---|
| [اكتب] | [اكتب] | [اكتب] | [اكتب] | [اكتب] | [اكتب] |

## B. Actual customer interview card
- User segment, city and contact consent (do not retain names in public report).
- Last time you faced the problem, what happened?
- What did you try? What did it cost in money/time/trust?
- Who decided? Who paid? What was the real obstacle?
- What evidence would prove repeated demand? Do not lead the interviewee.
- Quote (anonymized); observation; interpretation; next test.

## C. Competitor/analogue comparison
|اسم حقيقي/حالة بديلة| بلد/مدينة| مباشر/غير مباشر/بديل| نموذج الإيراد| مصدر مؤكد| ماذا نتعلم؟| ما الذي لا ينقل للسوق المحلي؟|
|---|---|---|---|---|---|---|

## D. Financial driver workbook (fill units and month)
Currency: ___ ; Base month: ___ ; source: ___
Customers reached: ___; conversion%: ___; paying customers: ___; units per customer: ___
Unit price: ___ ; refunds/discounts: ___; revenue collected: ___
Variable fulfillment cost: ___; fees: ___; returns/warranty: ___; unit contribution: ___
Fixed cash costs: ___; month-start cash: ___; burn: ___; runway: ___ or 'not calculable'
Downside/base/upside: assumptions stated; no invented market benchmark.

## E. 30/60/90-day plan
| اليوم | أولويات | فرضية | مالك المهمة | تكلفة/عملة | دليل مطلوب | قرار عند النجاح/الفشل |
|---|---|---|---|---|---|---|
|7| | | | | | |
|30| | | | | | |
|60| | | | | | |
|90| | | | | | |
