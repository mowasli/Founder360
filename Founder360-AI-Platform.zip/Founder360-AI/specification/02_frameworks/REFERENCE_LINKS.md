# Curated official links (access + licensing review required)

- **IdeaProof illustrative example** — https://ideaproof.io/example-report  
  Use: case report UI benchmark; access: reference only; caution: illustrative report; partly synthetic; DO NOT treat its numbers as verified external facts.
- **IdeaProof methodology** — https://ideaproof.io/research-methodology  
  Use: architecture inspiration; access: reference only; caution: only if currently accessible; no imitation or proprietary data copying.
- **Business Model Canvas | Strategyzer** — https://www.strategyzer.com/library/the-business-model-canvas  
  Use: business model dimensions; access: external template link; caution: free download/share per page; independently review permitted AI ingestion.
- **Value Proposition Canvas | Strategyzer** — https://www.strategyzer.com/library/the-value-proposition-canvas  
  Use: jobs pains gains; access: external template link; caution: download/share template per page; no copying protected prose into model.
- **The Lean Startup principles** — https://theleanstartup.com/principles  
  Use: experimentation/learning; access: reference only; caution: citation/reading; obtain rights before full ingestion.
- **Y Combinator Startup School** — https://www.startupschool.org/faq  
  Use: founder learning; access: reference only; caution: free educational access not training license.
- **Y Combinator Library** — https://www.ycombinator.com/library  
  Use: customer discovery/growth; access: reference only; caution: video/articles not automatically reusable in training.
- **NSF I-Corps** — https://www.nsf.gov/funding/initiatives/i-corps/information-accepted-national-teams  
  Use: hypothesis testing; access: reference only; caution: source of customer discovery practice; original questions in this pack.
- **World Bank Enterprise Surveys** — https://microdata.worldbank.org/collections/enterprise_surveys  
  Use: emerging market firm environment; access: registration / data access; caution: some datasets free registration; obey dataset terms & sampling scope.
- **World Bank Business Ready** — https://www.worldbank.org/en/businessready/data  
  Use: regulatory context; access: data download; caution: confirm dataset-specific terms; country coverage varies.
- **World Bank WDI API** — https://datahelpdesk.worldbank.org/knowledgebase/articles/889392  
  Use: population/income/macro; access: open API no key; caution: verify license/attribution at indicator level.
- **World Bank Entrepreneurship Database** — https://www.worldbank.org/en/programs/entrepreneurship  
  Use: entrepreneurial context; access: Excel download; caution: formal LLC registrations; NOT addressable customers or startups universe.
- **GEM 2025/2026** — https://www.gemconsortium.org/reports/latest-global-report  
  Use: context benchmark; access: download report; caution: public download is not blanket AI training permission.
- **Startup Genome GSER 2026** — https://startupgenome.com/report/the-global-startup-ecosystem-report-2026/introduction  
  Use: ecosystem benchmark; access: download report; caution: public download may require form and license; ecosystem-level only.
- **GSMA Mobile Economy MENA 2025** — https://www.gsma.com/solutions-and-impact/connectivity-for-good/mobile-economy/mena/  
  Use: regional connectivity; access: download report; caution: verify data period, avoid mistaking mobile users for paying buyers.
- **GSMA Mobile Economy Africa 2026** — https://www.gsma.com/solutions-and-impact/connectivity-for-good/mobile-economy/africa/  
  Use: digital inclusion; access: download report; caution: verify licensing; context only.
- **ILOSTAT bulk download** — https://ilostat.ilo.org/data/bulk/  
  Use: employment/sector; access: CSV bulk; caution: check each series metadata/license.
- **UN Comtrade API** — https://comtradeplus.un.org/en/api-docs  
  Use: trade/import/export; access: public preview limited; account for more; caution: free preview 500 rows; full access may be paid.
- **WIPO IP Statistics Data Center** — https://www.wipo.int/en/web/ip-statistics/  
  Use: IP signals; access: view/download; caution: no commercial resale of datasets; attribution required.
- **IFC MSME Finance** — https://www.ifc.org/en/what-we-do/sector-expertise/financial-institutions/msme-finance  
  Use: finance gap; access: download factsheet; caution: context not startup-level credit decisions.
- **OpenStax Entrepreneurship** — https://openstax.org/books/entrepreneurship/pages/index  
  Use: human curriculum only; access: READ ONLY until licensed for AI ingestion; caution: OpenStax explicitly requests prior written permission for LLM training/AI offerings; NC-SA terms.
