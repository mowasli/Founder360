# Knowledge sourcing policy and permissions matrix

Treat the `source_registry.csv` as a directory, NOT a downloaded vector database. A public web page is not automatically available for LLM training or commercial RAG ingestion. Store metadata + original authored methodology; link to third-party documents until their terms expressly allow your intended AI use. Seek written permission when needed.

High-priority: founder-supplied information with explicit processing consent; governmental/open-data APIs and microdata that the license permits; official business registers; public current company web pages for factual verification under the provider's permitted access. Distinguish quotation and factual extraction from bulk copyrighted reproduction.

World Bank Enterprise Surveys: company-level surveys are sampled from a particular population; not a database of every startup. The World Bank Entrepreneurship database captures formally registered limited liability businesses, not the TAM of a user's specific startup. B-READY is national-level business environment evidence, not personalized legal advice.

GEM/Startup Genome/GSMA/IFC reports: useful for macrocontext; their download availability does not establish permission to upload entire texts into a hosted third-party AI platform. Do not guess sector-specific numbers from macro reports.

OpenStax Entrepreneurship: website expressly states textbook content may not be used in LLM training or AI offerings without prior written permission; therefore link for HUMAN reading only until permission is granted. Check license at time of use.

UN Comtrade: public no-key preview endpoint has up to 500 records; paid/registered access required for larger datasets. WIPO statistical service has explicit reuse/re-sale restrictions and attribution requirements.

For all sources record: original URL, dataset or publication version, published date, retrieved date, geographic/sector coverage, license verification date, licence/terms URL, approved allowed uses, and removal/refresh policy. Never bypass paywalls, access controls or robots/TOS restrictions.
