# Protocol: Adaptive founder interviews + evidence

## Stages
- idea: 0 transactions, untested problem; interviews and alternatives matter more than CAC.
- discovery: interviews and initial problem tests.
- prototype: clickable or physical model, usability tests.
- mvp: usable MVP with initial users, no required revenue.
- early_revenue: live paying customers with basic transaction records.
- growth: meaningful repeated sales, documented retention and operating processes.

## Core question selection
1. Ask 6 intake questions before topic modules: geography, segment, stage, business model, paying/active status, founder's top challenge.
2. Ask each of 20 pillars at least one stage-applicable core question in first pass, except genuinely inapplicable ones with justification.
3. Rank questions by expected information gain: (high decision impact × uncertainty) / answer burden.
4. Target 25–45 questions in 20–35 minutes for the first pass; show progress, allow pauses. Escalate selectively after contradictions.
5. For every numerical answer require currency, measurement unit, period, numerator/denominator and source.
6. Conditional branches: B2B -> procurement/sales cycle; marketplace -> both sides/liquidity; SaaS -> activation/cohorts/churn; services -> labor utilization; manufacturing -> variable material/warranty; fintech/healthtech -> licensing and safe operations; low-connectivity -> cash/offline/last-mile.
7. If user has no users, do NOT ask for MAU/retention as required. Turn those into proposed measurements.
8. Attach optional evidence: product screenshots, anonymous interviews, invoice summary, anonymized sales, customer-feedback summaries, budget, contracts, analytics. Redact names, IDs, medical records and unnecessary PII.

## Claim classes and confidence
- founder_reported: quote or answer; not independently proven.
- verified_external: independent traceable source, with URL and observed date.
- calculated: deterministic formula and specific input references.
- estimated: scenario built on disclosed assumptions, range, sensitivity.
- hypothesis: test required.
- unknown: no defensible claim.

Avoid false numeric certainty: confidence is qualitative low/medium/high with explicit reasoning; confidence does not equal probability of success. A missing datum remains null.

## Research methodology
Use triangulation. Verify official company existence and product first; compare current prices only when posted and dated. Document search terms and languages. Scope local alternatives broadly: offline, paper, WhatsApp, incumbent distributors, unregistered businesses and institutional workarounds. Absence of web results does not prove absence of competition.

## Experiment card
For each critical assumption produce: hypothesis; null alternative; cohort/segment; recruitment; task; baseline; pass/fail thresholds (provisional unless tied to founder constraints); length; approximate spend and explicit currency; possible bias; responsible owner; decision after result. No nonsensical threshold such as '10 interviews confirms product-market fit'.
