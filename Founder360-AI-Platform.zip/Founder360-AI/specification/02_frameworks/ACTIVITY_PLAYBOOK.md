# Incubator activity guide — Founder360 reflection workshop

## Objective
Improve the founder's capacity to distinguish belief from evidence and execute the next most decisive test; not label winners/losers.

## Facilitation (example 2 sessions)
Session A (90 min): 10 min consent & framing; 15 min company map and stage; 30 min adaptive diagnostic; 20 min verification of contradictions; 15 min pair reflection on top 3 assumptions.
Between sessions: do at least one low-cost real-world test appropriate to constraints, collect proof in non-identifying form.
Session B (90 min, after 1–2 weeks): 15 min explain score vs evidence coverage; 25 min challenge competitor/market comparisons; 30 min build 30/60/90 action roadmap; 20 min founder-mentor commitment.

## Suggested assessment cadence
Baseline (first week), mid-program (after evidence tests), final (end of incubation). Compare on same methodology version and disclose if weights changed.

## Mentor review protocol
Mentors can comment on claims, request evidence, approve an experiment, and mark an action complete, but cannot quietly change an underlying verified source or overwrite founder data. Score revisions are logged.

## Success metrics for the incubation program
Proportion of founders who complete onboarding, provide first-party evidence, conduct customer tests, discover or falsify core assumptions, deliver paid pilots, improve contribution margin, and close their highest-priority gaps. Do not claim causal impact without comparison design.
