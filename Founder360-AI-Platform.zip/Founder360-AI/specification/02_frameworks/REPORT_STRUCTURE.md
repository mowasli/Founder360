# Report blueprint: Founder360 (deep, actionable, 30–60 pages as evidence allows)

1. Cover: startup, city/country, phase, date, prepared-for, research completeness and warning.
2. Executive diagnostic: concise venture snapshot, three strengths, five critical weaknesses, a conditional direction (PROCEED WITH TEST / ITERATE / PAUSE & VERIFY), never binary certainty.
3. Evidence coverage dashboard: pillar score (0–4 or Unknown), weighted diagnostic score only if eligible; confidence, freshness, unknown rate, no 'success probability'.
4. The founder's business in one page: customer -> pain -> current workaround -> product -> transaction -> cost -> revenue -> delivery.
5. Problem evidence and customer interview synthesis, verbatim anonymized testimony (if provided), sampling caveats.
6. Segmentation, jobs-to-be-done, buyer/user/decision maker map, buyer journeys.
7. Value proposition fit: before/after job, differentiators, promised outcome, hypothesis register.
8. Product usability, MVP scope, activation funnel, user experience and digital inclusion.
9. Market: exact target boundary; TAM/SAM/SOM bottom-up method + alternative; dated sources; ranges; sensitivity.
10. Competitors & substitutes: 3–8 real documented matches if available, local first, rival matrix, white spaces, meaningful differences.
11. Business models analogues: up to 3–5 verifiable companies and monetization patterns, transferability and local barriers.
12. Business model economics and pricing: who pays, pricing options, collection and cash conversion.
13. Unit economics with calculator traces, break-even math and unresolved data requirements.
14. Cash/financial view: reconciled actuals vs forecasts, drivers, three scenarios, runway if calculable.
15. Customer acquisition, channels, GTM playbooks, B2B sales, repeat sales and retention.
16. Delivery/operations, supplier constraints, service quality and growth bottlenecks.
17. Team, role ownership, governance, skills gaps and realistic recruiting priorities.
18. Technology, data protection, cyber, intellectual property and necessary jurisdiction-specific legal checks.
19. Partnerships, access to market, procurement and capital strategy without assuming VC suitability.
20. Risk register: probability category, severity, detectability, mitigations, early warning indicator and owner; local infrastructure/FX issues when material.
21. 20-pillar audit annex: each pillar has reasoned status, pros/cons, evidence citations, challenges, priority and actionable tasks.
22. Critical assumptions ranked by (impact × uncertainty × cost of delay); decision tests with pass/fail signals.
23. Week 1 checklist; 30/60/90-day founder action plan with budget, owner, KPI, dependency and quality gate.
24. Customized templates: 10 customer interview questions, 1 MVP test, 1 pricing test, 1 sales script, 1 simple financial calculator/input sheet, 1 single-page Lean Canvas narrative.
25. Mentor notes: open questions, coaching agenda and evidence required before next session.
26. Sources & methods: every external source URL/date, citations to founder files, calculations, assumptions, unresolved disputes and model/data version.

Presentation: readable Arabic RTL and English LTR, charts from actual data only, no filler pictures; PDF and HTML export with clickable sources, copyable experiments and download JSON.
