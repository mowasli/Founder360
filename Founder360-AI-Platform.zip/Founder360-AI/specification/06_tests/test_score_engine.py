import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'05_implementation'))
from score_engine import compute_diagnostic, compute_pillar_score, unit_economics, runway_months
class EngineTests(unittest.TestCase):
 def test_all_scored(self):
  d=compute_diagnostic([{'id':str(i),'weight':5,'score':3} for i in range(20)])
  self.assertEqual(d['overall_score'],75.0)
 def test_unknown_not_zero(self):
  d=compute_diagnostic([{'id':str(i),'weight':5,'score':None if i<11 else 4} for i in range(20)])
  self.assertIsNone(d['overall_score'])
 def test_na_not_counted(self):
  d=compute_diagnostic([{'id':str(i),'weight':5,'applicable':i<12,'score':4 if i<12 else None} for i in range(20)])
  self.assertEqual(d['overall_score'],100.0)
 def test_contribution(self):
  self.assertEqual(unit_economics(100,60,500,10)['cac'],50)
 def test_runway(self):
  self.assertEqual(runway_months(9000,3000),3.0)
 def test_pillar_partial(self):
  d=compute_pillar_score([{'score':3},{'score':4},{'score':2},{'score':None},{'score':None}])
  self.assertEqual(d['score'],3.0)
 def test_pillar_withheld(self):
  d=compute_pillar_score([{'score':4},{'score':None},{'score':None},{'score':None},{'score':None}])
  self.assertIsNone(d['score'])
 def test_invalid(self):
  with self.assertRaises(ValueError): compute_diagnostic([{'id':'x','weight':1,'score':10}])
if __name__=='__main__': unittest.main()
