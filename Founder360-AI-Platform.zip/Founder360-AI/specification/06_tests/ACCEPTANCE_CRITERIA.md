# Acceptance criteria & release gate

- [ ] 20 pillars / 100 distinct criteria available, stage-aware, non-applicable logic documented.
- [ ] Arabic and English questions render correctly; Arabic RTL visual review and keyboard/screen reader support.
- [ ] At least 25–45 useful questions first pass, no 140-question wall; pause/resume works.
- [ ] 'I don't know' causes null/not scored, not artificially low grade.
- [ ] Computed score comes from one deterministic engine, not text synthesis; calculations audited.
- [ ] Overall score withheld if weighted evidence coverage < 60% OR fewer than 10 scored pillars.
- [ ] Market sizing shows units, source year, TAM/SAM/SOM assumptions; no automatic baseless 2% SOM.
- [ ] 3 sectors tested: local service, SaaS and marketplace; initial idea and early revenue stages.
- [ ] Cross-check input: 10 customers × price 100 vs claimed revenue 5000 -> warning rather than silent overwrite.
- [ ] Competitor examples have live source URLs and local -> regional -> global fallback with nonmatching cases rejected.
- [ ] Contradictory web sources both visible; freshness and geography visible.
- [ ] Missing external search tools -> marked offline/unverified, NEVER fabricated competitor.
- [ ] Financial model doesn't generate LTV without retention basis; CAC denominator verified as new paying customers.
- [ ] Every decisive external assertion cited; every estimate labelled and recalculable.
- [ ] 30/60/90 plan has owner, experiment, time, cost/currency, metric, falsification threshold and dependency.
- [ ] Report validates against `report_schema.json`, exports full PDF with working Arabic and clickable references.
- [ ] Founder records segregated by tenant; unconsented model training absent; deletion/export works.
- [ ] Protected against prompt injection in uploaded files/web pages.
- [ ] API cost caps, retries, queues, access logs, source/license registry.
- [ ] Mentor dashboard available with first and follow-up scores and version annotations.
- [ ] Pilot tested with 3–5 real founders and independent mentor feedback; scores revised only via versioned rubric.

Failing a requirement means production readiness cannot be claimed. Distinguish PASS / FAIL / NOT TESTED in deployment report.
