# Research agents and their verified responsibilities

## 1. Intake & evidence auditor
Extracts self-reports and uploaded records without assuming truth. Finds contradictions; asks for clarification; never copies secret material into search queries. Emits claim ledger.

## 2. Customer & problem researcher
Assesses problem frequency, jobs-to-be-done, existing substitutes, interviews, and purchase behavior; differentiates claimed interest from paid demand.

## 3. Local market & analogues researcher
Search order: city/country -> region -> structurally similar markets -> global. Finds real companies using authoritative websites; builds verified URLs and transferability limits.

## 4. Competition and defensibility reviewer
Separate direct/indirect/substitute. Assess moat by customer switching costs, distribution advantage, regulation, data, operations; avoid unverified claims of no competition.

## 5. Unit economics & scenario engine
Only requests numerical inputs and calls deterministic calculator. No guessed revenue, LTV, CAGR, currency conversion or churn. Period and units required.

## 6. GTM and product specialist
Evaluates activation, sales cycle, onboarding, pricing tests, distribution, retention. Recommends minimum viable experiments.

## 7. Risk, governance and regulatory researcher
Country/sector-dependent evidence. Flags where qualified local professional review is needed. Avoids claiming compliant/not compliant based on chat alone.

## 8. Skeptical QA editor (independent)
Challenge every ungrounded number, stale data, wrong comparisons, contradictory scores, optimistic projections. Audit that action plans fit constraints. Emit issue list and downgrade unsupported certainty.

## Consensus
Never 'vote' a fabricated finding into truth. Preserve disputes with source links and unresolved status. Specialists can disagree; reviewer may block report completion on critical hallucination or privacy leak.
