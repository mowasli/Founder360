# API and workflow

All app endpoints are under `/api/v1`. The complete executable contract is served at `/openapi.json` and included as `docs/openapi.json` in the deliverable. Server sessions use HttpOnly cookies; mutations after sign-in require the `X-CSRF-Token` value returned by `/auth/me`. No bearer API key is exposed to the browser.

| Method / route | Purpose |
|---|---|
| POST /auth/register, /auth/login, /auth/logout | Local accounts and hashed server sessions |
| POST /auth/trial | Isolated, development-only 24-hour synthetic workspace; no real data |
| GET /catalog | Original 20 pillars, 100 criteria and permissions directory |
| GET /capabilities | Honest runtime integration status; no secrets |
| POST /startups; PUT /startups/:id | Founder-owned context and distinct consent flags |
| GET /startups | Owned/consented/assigned startups only |
| POST /assessments | Baseline or follow-up; optional prior-answer copy without verified evidence |
| GET /assessments/:id | Saved answers, evidence, reviews, sources, tasks, notes and revision |
| GET /assessments/:id/next-questions | First/deep adaptive queue and progress; one question first |
| POST /assessments/:id/answers | Explicit unknown/N/A; numeric measurement metadata required |
| GET/PUT /assessments/:id/finance | Independent deterministic calculator and input audit |
| POST /assessments/:id/evidence | Authorized encrypted local upload, 10 MB max |
| GET /assessments/:id/evidence/:file | Scoped encrypted-file download as attachment |
| GET /assessments/:id/research-preview | Exact public-only search scope |
| POST /assessments/:id/sources | Real source metadata, unverified by default |
| POST /assessments/:id/sources/:source/review | Mentor/admin source review; attributable history |
| POST /assessments/:id/criteria/:criterion/review | Versioned human rating; evidence required for 2–4 |
| POST /assessments/:id/analyze | Idempotent durable analysis job over a fixed input snapshot |
| GET /jobs/:id; POST /jobs/:id/retry | Safe stage/status and bounded non-paid replay |
| GET /assessments/:id/report[.json/.html/.pdf] | Schema-validated full report; current task updates included |
| GET /assessments/:id/history[/version] | Immutable generated reports and before/after review events |
| PATCH /assessments/:id/tasks/:task | Owner/note/status follow-up without overwriting input evidence |
| POST /assessments/:id/mentor-comments | Founder/mentor coaching notes |
| GET /startups/:id/comparison | Within-company baseline/follow-up and compatibility gates |
| GET /startups/:id/export | All structured company data, versions and reviews |
| DELETE /startups/:id/data | Founder-authorized live data/file cascade |
| POST /admin/invitations | Single-use role-limited program invitations |
| POST /admin/startups/:id/assign/:mentor | Same-program mentor assignment |
| PUT /admin/brand | Program name, accent and local PNG/JPEG logo |
| GET /admin/audit; GET /metrics | Admin-only metadata audit and operational counts |

Unknown applicable data is retained in denominators. Explicitly stage-inapplicable post-launch metrics have recorded reasons. Analysis produces a snapshot; later answer/profile/finance/source/review changes mark reports stale. An in-flight job cannot overwrite a newer assessment revision. A job that attempted a paid provider call is not automatically replayed after an uncertain failure.
