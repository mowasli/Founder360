# Deployment and integration

This delivery is a local pilot. The actual application server was tested with SQLite, encrypted files and synthetic accounts. Docker, hosted PostgreSQL, RLS deployment and live AI calls are provided as setup paths and are **not** claimed to have been executed in the delivery environment.

## Run a private pilot

1. Follow README setup; install with a clean virtual environment.
2. Keep `.data`, `.env.local`, keys and backups outside source control. Change development settings before production.
3. Provision a program manager with the management CLI. Normal signup cannot create administrators. The admin creates single-use invitations; mentors require assignment and founder sharing consent.
4. Run on a loopback/private interface and expose through your TLS reverse proxy. `deploy/nginx.conf.example` illustrates a dedicated hostname. Set `ALLOWED_ORIGINS` to the deployed origin and `APP_ENV=production`; supply a fixed `DATA_ENCRYPTION_KEY` through your secret manager. Secure cookies require HTTPS.
5. Use one application process/worker for SQLite; mount durable `.data` storage. Do not share a SQLite file over NFS or across replicas. Private files are encrypted and served only through authorized attachment endpoints.
6. Define retention and deletion policy, encrypted backup storage and operator permissions. Current evidence retention dates are metadata; automatic scheduled evidence deletion requires operator policy. Trial expiration blocks access but cleanup is an explicit maintenance command.
7. Keep production synthetic trial and demo seeding disabled. Add verified-email/OIDC/reset flows if your rollout requires them; local password accounts alone do not provide those services.

## Container

```bash
cp .env.example .env.local
# Edit .env.local: production environment, encryption key, origin and any service settings.
docker compose build
docker compose up -d
docker compose exec web python scripts/manage.py create-admin --email manager@example.org
```

Use an interactive terminal for the administrator password prompt. Compose binds only `127.0.0.1:8000`; your reverse proxy owns public HTTPS. There are no built-in default passwords.

## Optional PostgreSQL

Install dependencies from `requirements.txt`, provision PostgreSQL and a restricted service role, initialize the application schema using a migration role, apply `deploy/postgres-rls.sql`, then set `DATABASE_URL` in the service. Use a non-owner application role without BYPASSRLS. Business transactions set `app.org_id` locally. Users/sessions, invitations and encrypted queue metadata are service-scoped because sign-in and job claiming precede tenant context; API authorization remains mandatory in every endpoint.

Run the same tests against a dedicated test PostgreSQL instance before enabling real accounts. Do not set `DATABASE_URL` to a production database while running the test suite. This build's automated test suite was run against SQLite only. Queue leases and request reservations prevent accidental job duplication; SQLite runs one worker and PostgreSQL claims use `FOR UPDATE SKIP LOCKED`.

## Existing incubator website

Prefer a same-brand subdomain, linked from your incubator site. Brand name/accent/logo are organization settings. A subdomain avoids fragile relative asset paths and keeps secure session cookies and API routes on one origin.

For a path such as `/founder360/`, configure Vite `base`, a FastAPI `root_path`, reverse-proxy prefix handling and API URL prefix together, then rerun UI/API/export tests. Path-prefix deployment is **not preconfigured** in this delivery. An iframe requires an intentional `frame-ancestors` allow-list and compatible same-site cookie arrangement; do not disable authentication or broadly relax CSP merely to embed the app. The shipped CSP permits same-origin framing only.

## External models and search

`backend/app/providers.py` uses server-only HTTP adapters. OpenAI: Responses API and `web_search`; Anthropic: Messages API and web-search tools. Confirm your chosen model and current provider terms, retention settings and data residency. No full book or report is uploaded into AI by this code.

Configure the key with a secret manager, set `AI_PROVIDER`, `AI_MODEL`, token caps, monthly budget and conservative per-request reservation. Keep provider-side spending limits enabled. Internal reservations are estimates and do not guarantee the provider invoice; token and request-count caps are hard software limits. An ambiguous failure remains reserved and automatic replay is blocked. External provider behavior must be validated with small approved tests before founder use.

Research discloses public queries in advance and makes ordered local/regional/comparable/global requests. Citation URLs are taken from provider-returned citation annotations; invented/uncited links and declared nonmatching candidates are rejected. A citation does not automatically verify a company or comparison. An authorized reviewer checks geography, model, freshness and comparison limits before a source becomes `verified_external`. Conflicting sources remain visible; sources expire after 90 days unless reviewed again.

AI narrative can receive only explicitly selected, redacted excerpts from consented founders. It cannot set scores or financial outputs. Model suggestions are hypotheses with allowed answer IDs, not trusted instructions or verified facts. Prompt-injection defenses reduce attack surface through excluded files, public query minimization and output constraints; they are not a formal guarantee against every model attack. Independent adversarial testing is still needed for a live provider.

## Verification and operations

Run tests, build, `/healthz`, an AR/EN browser journey, PDF download and a backup/restore drill after deployment. `/metrics` requires an admin session. API access/audit events record actor/entity/action/time without answer text or keys. Server access logging is disabled by default; configure privacy-safe infrastructure logs separately.

Export company JSON before deletion; original evidence files have separate authorized download links. Deletion cascades active assessments, answers, reports, sources, reviews, tasks and encrypted file bytes. Metadata-only audit/provider accounting remains. Apply your backup-retention policy separately; no live deletion can erase previously retained backups automatically.

## Service changes to plan before scale

OIDC/email verification/reset, private object storage with presigned upload URLs, enterprise malware scanning, signed report audit attestations, distributed observability/rate limits, independent penetration testing, proven PostgreSQL RLS deployment, recovery drills and a pilot with 3–5 real founders are not bundled as already-connected services. Do not call the platform production-ready until the release gate and your deployment controls pass.
