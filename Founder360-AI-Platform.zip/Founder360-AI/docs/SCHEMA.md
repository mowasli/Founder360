# Storage schema and authorization

The executable SQL is `backend/app/storage.py:SCHEMA`. Encrypted payloads are opaque authenticated Fernet ciphertext; raw founder answers, financials, names/emails, source excerpts, reviews, reports and files are not stored as plaintext. IDs, organizational roles, status, timestamps and content digests are metadata. Keep the encryption key outside backups in production.

| Entity | Key / relations | Behavior |
|---|---|---|
| organizations | id, settings | Incubator identity and encrypted brand settings |
| users | id, org_id, email_hash | Encrypted profile, scrypt hash, one organization and one role per account |
| sessions | token hash, user_id | HttpOnly SameSite session; CSRF token; 8-hour account sessions |
| startups | id, org_id, owner_id | Encrypted context and explicit program-sharing consent |
| assignments | startup_id, mentor_id | Only assigned mentors can access shared records |
| assessments | id, startup_id | Rubric/rules, input revision, encrypted state, latest report |
| answers | assessment_id + question_id | Stable original question IDs, response class, measurements, evidence links |
| evidence | id, assessment_id | Private encrypted bytes, digest, type, size and retention metadata |
| ratings | assessment_id + criterion_id | Explicit reviewer rationale and attributable evidence |
| sources | id, assessment_id | Source URL/date/geography/license/status/conflicts; no scraped corpus |
| tasks | id, assessment_id | Owner, deadline, budget unknown/quoted, dependency, metric and pass/fail gate |
| comments | id, assessment_id | Founder/mentor notes; cannot silently replace founder answers |
| jobs | id, assessment_id | Durable queue, lease, revision, idempotency, safe stage/error |
| report_versions | id, assessment_id | Immutable generated report snapshots, input revision and creation time |
| review_events | id, assessment_id | Encrypted before/after source or criterion review trail |
| audit_logs | id, org_id | Metadata-only actor/action/entity/time; no business text or secrets |
| provider_calls | id, org_id | Persistent request reservations and usage metadata, never API keys |
| invitations | token hash, org_id | Single-use founder/mentor invitation; expires after 7 days |

All business-child records cascade when a startup is deleted. Non-content audit and provider-accounting metadata remain. SQLite backups require an operator retention/deletion policy; deleting a live row cannot rewrite previously archived backups.

The application checks organization, ownership, sharing consent and mentor assignment on every sensitive endpoint. Program administrators can review evidence, create invitations and assign mentors, but cannot edit founder answers. Founder statements default to a provisional 1 at their single mapped indicator; missing/unknown/N/A responses do not silently become zero or exclude a whole pillar. A higher rating requires a human reviewer and attributed evidence.

Local SQLite uses WAL and a single application worker. Optional PostgreSQL uses tenant-scoped transactions with `app.org_id`; apply `deploy/postgres-rls.sql` using a migration role after schema initialization. The service role must not own tenant tables and must not have BYPASSRLS. Auth/session/job metadata is service-scoped; business tables have forced RLS. This PostgreSQL path is provided but was not integration-tested in the delivery environment.
