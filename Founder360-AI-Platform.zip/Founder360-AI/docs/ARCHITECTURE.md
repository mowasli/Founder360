# Founder360 AI - Architecture decision record

Status: runnable local release candidate, not a production certification.

## Components
- React bilingual single-page application, built by Vite and served on the same origin as the API. No browser API keys or third-party analytics.
- FastAPI REST API, OpenAPI at /docs; opaque, hashed server sessions with HttpOnly SameSite cookies, CSRF tokens and tenant/owner/assigned-mentor checks.
- SQLite WAL durable database for a local single-worker deployment. PostgreSQL via DATABASE_URL uses the same repository layer; production RLS policy migration is provided and requires an application role without BYPASSRLS.
- Encrypted JSON fields and private encrypted file storage. A local encryption key is generated on first local run; production requires a supplied key. Uploaded documents are never sent to models automatically.
- Durable jobs table and leased background worker, snapshots and idempotency keyed by assessment content. Retries are bounded; external reservations are atomic and deliberately not automatically retried.
- Pure Python scoring and Decimal financial functions. Models cannot write financial outputs or scores.
- Provider-neutral research gateway with explicit consent, public-only queries, citation allow-listing, human review before verification, request/token caps and persistent call reservations. No live API configured in this delivery.
- Server-rendered HTML and PDF with Arabic shaping using ReportLab with bundled Noto fonts and per-line Arabic shaping. Report JSON is validated against the supplied schema.

## Data flow
Intake + processing consent -> startup -> versioned assessment -> adaptive first pass -> evidence/finance -> conflict review -> durable analysis job -> 20-pillar report -> experiments and 7/30/60/90 tasks -> follow-up assessment -> same-rubric comparison.

## Trust boundaries
Every read/write is authorized in the API and scoped in the repository. A manager sees shared startups in their organization; mentors only assigned, consented startups. Founder data, sources and files are untrusted data and never system instructions. External research receives only the previewed geography/sector/business-model terms. AI narrative receives founder-selected/redacted text only when separately consented; attachments are excluded. Citation candidates are not automatically verified. Sources have license status and expiry metadata.

## Deliberate boundaries
Local password accounts are implemented. OIDC, email verification/reset, object-store presigned uploads, enterprise antivirus, independent security audit and a real-founder pilot require deployment work. SQLite is not advertised as managed multi-region infrastructure. No protected third-party corpus is ingested; external source registries contain links and rights metadata only.

## Versioning
Original specification retained in /specification. Methods version 1.0.0, application rules 1.0.0-local. Original base weights remain unchanged. Stage applicability excludes only measured post-launch retention/CAC criteria before use; reasons remain in the report. Reports record input digest, version and claim references.
